#include "../include/Dot.h"



/* BUT : Utilise dot 
*  Paramètres : FILE *out -> fichier de sortie
*  Renvoi : void
*/
static void ecrireDebut(FILE * out){
  fprintf(out, "digraph arbre {\n");
  fprintf(out, "\tnode [shape=record,height=.1]\n");
  fprintf(out, "\tedge [tailclip=false, arrowtail=dot, dir=both];\n");
}



/*

static void ecrireArbre(FILE * out, Arbre a){


    if(a == NULL) {
        return;
    }

     
    fprintf(out, "\n");
    fprintf(out, "n%p [label= \"<gauche>  | <valeur> %s temps_fct: %f temps_cumul: %f | <droit>\"]", a, a->name, a->real_times, a->temps_inst);
          

    if(a->fg != NULL ){
      
      fprintf(out, "n%p : gauche : c -> n%p : valeur;", a, a->fg);
        
    }

    if(a->frd != NULL ){
       
        fprintf(out, "n%p : droit : c -> n%p : valeur;", a, a->frd);
        
  }

    ecrireArbre(out, a->fg);
    ecrireArbre(out, a->frd);

}
*/




static void ecrireArbre(FILE * out, Arbre a){


  if(a == NULL) {
      return;
  }

  if (strcmp(a->name, "END")) {
    fprintf(out, "\n");
    fprintf(out, "n%p [label= \"<gauche>  | <valeur> %s tmp_fct %f  tmp_cumul %f | <droit>\"]", a, a->name,  a->temps_inst, a->real_times);
      
    

    if(a->fg != NULL && strcmp(a->fg->name, "END")){
      fprintf(out, "n%p : gauche : c -> n%p : valeur;", a, a->fg);

    }

    if(a->frd != NULL && strcmp(a->frd->name, "END")){
      fprintf(out, "n%p : droit : c -> n%p : valeur;", a, a->frd);
    }

  }

  ecrireArbre(out, a->fg);
  ecrireArbre(out, a->frd);

}




/* BUT : Utilise dot 
*  Paramètres : FILE *out -> fichier de sortie
*  Renvoi : void
*/
static void ecrireFin(FILE * out){
  fprintf(out, "\n}\n");
}


/* BUT : Utilise dot poure afficher un arbre
*  Paramètres : Arbre a   -> arbre à afficher
*  Renvoi : void
*/
void dessine(Arbre a){

  FILE * out;
  out = fopen("arbre.dot", "w");
  ecrireDebut(out);
  ecrireArbre(out, a);
  ecrireFin(out);
  fclose(out);
  system("dot -Tpdf arbre.dot -o arbre.pdf");
  system("evince arbre.pdf &");
}  