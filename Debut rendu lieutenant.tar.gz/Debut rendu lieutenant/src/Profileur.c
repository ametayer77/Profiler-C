#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../include/Arbre.h"
#include "../include/Graphic.h"
#include "../include/Dot.h"


int main( int argc, char *argv[] ){

  Arbre a = NULL;
  Arbre b = NULL;
  
  FILE *fichier;
  double test = 0;
  double inst = 0;
  double frd = 0;
  int effectif = 0;
  fichier = fopen("profile.log", "r");

  construitArbre(&a, fichier);

  rewind(fichier);
  construitArbre(&b, fichier);
  ModifieArbre(&b, &test, &inst, &frd);

  fclose(fichier);
  printf("hauteur %d\n",hauteur(b) );
  Ligne tab[hauteur(b)];

  ConstruireTab(b, tab, &effectif);
  CalculTemp_Moy(tab, effectif);
 
  
  AfficheTab(tab, effectif);/*
  

  printf("%lf + %lf = %lf\n",tab[1].temps_moy, tab[2].temps_moy, tab[1].temps_moy+ tab[2].temps_moy );


printf("\n\n");
printf("\n\n");

qsort(tab, effectif, sizeof(Ligne), CompareAppel);
printf("Nb nb_appel\n");
AfficheTab(tab, effectif);
printf("\n\n");


qsort(tab, effectif, sizeof(Ligne), CompareName);
printf("name\n");
AfficheTab(tab, effectif);
printf("\n\n");



qsort(tab, effectif, sizeof(Ligne), CompareTime);
printf("times\n");
AfficheTab(tab, effectif);
printf("\n\n");


qsort(tab, effectif, sizeof(Ligne), CompareTemp_moy);
printf("temps_moy\n");
AfficheTab(tab, effectif);
printf("\n\n");
*/

/*
dessine(b);*/

Graphic(b);





  return 0;

}
