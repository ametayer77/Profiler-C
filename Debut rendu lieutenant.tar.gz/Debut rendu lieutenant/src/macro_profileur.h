





#ifndef PROFILE_MODE
#define PROFILE /*Empty Macro*/

#else

#define BILLION 1000000000L 

#define PROFILE struct timespec start; FILE* fichier = fopen("profile.log", "a");  \
        clock_gettime(CLOCK_REALTIME,&start); \
        double accum = (start.tv_sec ) + (double)(start.tv_nsec ) / (double)BILLION; \
        fprintf(fichier, "%s -- time : %.6lfs \n",__FUNCTION__, accum);  fclose(fichier); 

#define return struct timespec stop; clock_gettime(CLOCK_REALTIME, &stop); fichier = fopen("profile.log", "a"); \
        accum = ( stop.tv_sec ) + (double)( stop.tv_nsec ) / (double)BILLION; \
        fprintf(fichier,"END -- time : %.6lfs \n", accum); \
        fclose(fichier);  \
        return

#endif
