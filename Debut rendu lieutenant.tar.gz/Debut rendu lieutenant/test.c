void DessinRect(Arbre a, double *widht, double *height, double *x, double *y, MLV_Font* font, double ref, int couleur) {
  
  if (a == NULL) {
  return;
  }
  if (strcmp(a->name, "END")) {

  *widht =  (WIDHT * a->temps_inst) /ref;
  *height = (HEIGHT * a->temps_inst) /ref;
  printf("%s (%lf,%lf) %lf,%lf\n",a->name, *x, *y, *widht, *height );

   /*printf("%s (%lf,%lf) long %lf larg %lf \n",a->name, *x, *y, *widht, *height );*/
  MLV_draw_filled_rectangle(*x, *y, *widht, *height, MLV_rgba(255 -couleur, 0 +couleur, 0, 255));
    MLV_draw_rectangle(*x, *y, *widht, *height, MLV_COLOR_BLACK);

    /*Rectangle trop petit*/
    if (*height < 40) {
    	MLV_draw_text_with_font(*x, *y-10, "...", font, MLV_COLOR_WHITE);
    }
  else {
  	MLV_draw_text_with_font(*x, *y, "%s", font, MLV_COLOR_WHITE, a->name);
  }



  /*int z, e; MLV_wait_mouse(&e,&z); */
   MLV_actualise_window();
   /*Ecart le  plus esthétique*/
  
  
   

  }
  DessinRect(a->fg, widht, height, x , y , font, ref, couleur + STEP);
  /*printf("av ----%lf %lf\n",*x, *y );*/
  *x +=  *widht +40 ;
   *y = *height -20;
 
  DessinRect(a->frd, widht, height, x, y, font, ref, couleur);
  


}