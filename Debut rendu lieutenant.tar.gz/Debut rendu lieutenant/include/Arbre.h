/* AUTEURS : Metayer Ambre 
*  Creation 09-10-2018
∗  Modification  22-10-2018*/


#ifndef __Arbre__
#define __Arbre__ 



#include <stdio.h>
#include <stdlib.h>
#include <string.h>




/* Structure permettant de déclarer un type d'arbre */
typedef struct noeud {
  double times;
  char name[BUFSIZ];
  double real_times;
  double temps_inst;
  struct noeud *fg;
  struct noeud *frd;
}Noeud, *Arbre;



typedef struct {
  double times;
  char name[BUFSIZ];
  int nb_appel;
  double temps_moy;

}Ligne;



/* BUT : Construire un arbre à partir d'un fichier '*fichier'
*  Paramètres : Arbre *a      -> Arbre à construire
*               FILE *fichier -> fichier texte
*  Renvoi : void
*/
void construitArbre(Arbre *a, FILE *fichier);


/* BUT : Construire un arbre à partir d'un fichier '*fichier'
*  Paramètres : Arbre *a      -> Arbre à construire
*               FILE *fichier -> fichier texte
*  Renvoi : void
*/
double  ModifieArbre(Arbre *a, double *test, double *inst, double *frd);


int hauteur(Arbre a);

void afficheArbre(Arbre a);

void ConstruireTab(Arbre a, Ligne tab[], int *effectif);

void CalculTemp_Moy(Ligne tab[], int size);
void AfficheTab(Ligne tab[], int size);
int CompareAppel(const void * a, const void * b);

int CompareName(const void * a, const void * b);

int CompareTime(const void * a, const void * b);

int CompareTemp_moy(const void * a, const void * b);

#endif






