/* AUTEURS : Metayer Ambre 
*  Creation 09-10-2018
∗  Modification  22-10-2018*/


#ifndef __Dot__
#define __Dot__ 



#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#include "Arbre.h"


void dessine(Arbre a);



#endif