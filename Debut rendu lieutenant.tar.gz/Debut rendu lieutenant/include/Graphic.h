/* AUTEURS : Metayer Ambre 
*  Creation 09-10-2018
∗  Modification  22-10-2018*/


#ifndef __Graphic__
#define __Graphic__ 



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <MLV/MLV_all.h>


#include "Arbre.h"

/*Taille maximal de la fenêtre*/
#define WIDHT MLV_get_desktop_width() -150
#define HEIGHT MLV_get_desktop_height() -150

#define STEP 24


/*
void DessinRect(Arbre a, double *widht, double *height, double *x, double *y, MLV_Font* font, double ref, int couleur);
*/

void DessinRect(Arbre a, int widht, int height, int x, int y, MLV_Font* font, double ref, int couleur, int *tmp);

void Graphic(Arbre b);



#endif