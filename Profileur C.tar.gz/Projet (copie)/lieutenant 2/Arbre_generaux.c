/* AUTHOR : Metayer Ambre & Saouter Marion
*  Creation 15-11-2018
∗  Change  */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <MLV/MLV_all.h>



/*Taille maximal de la fenêtre*/
#define WIDHT MLV_get_desktop_width()
#define HEIGHT MLV_get_desktop_height()


#define MUL 10000
#define STEP 24




/* Structure permettant de déclarer un type d'arbre */
typedef struct noeud {
  double times;
  char name[BUFSIZ];
  double real_times;
  double temps_inst;
  struct noeud *fg;
  struct noeud *frd;
}Noeud, *Arbre;



typedef struct {
  double times;
  char name[BUFSIZ];
  int nb_appel;
  double temps_moy;

}Ligne;



/* BUT : Alloue un noeud d'un Arbre
*  Paramètres : int val -> étiquette du noeud
*  Renvoi : un pointeur sur un noeud
*/
Arbre AlloueNoeud(double times, char name[]) {

    Arbre tmp;
    tmp = (Arbre)malloc(sizeof(Noeud));

    if (tmp != NULL) {
        tmp->times = times;
        strcpy(tmp->name, name);
        tmp->fg = NULL;
        tmp->frd = NULL;
        tmp->real_times = 0;
        tmp->temps_inst = 0;
        
    }
    return tmp;
}





/* BUT : Construire un arbre à partir d'un fichier '*fichier'
*  Paramètres : Arbre *a      -> Arbre à construire
*               FILE *fichier -> fichier texte
*  Renvoi : le nombre de noeud qui à 2 fils
*/
void construitArbre(Arbre *a, FILE *fichier) {


  double times;
  char name[50];


    if(fscanf(fichier, "%s %*s %*s %*s %lf %*s",name, &times ) != EOF ) {



      (*a) = AlloueNoeud(times, name);
      if (strcmp(name, "END")) {

        construitArbre(&((*a)->fg), fichier);
         construitArbre(&((*a)->frd), fichier);
         return;
        
      }

      
    }
}

  



void  ModifieArbre(Arbre *a, double *test, double *inst, double *frd) {

  if (*a == NULL) {

    return;

  }

  ModifieArbre(&(*a)->fg, test, inst, frd);




  if (!strcmp((*a)->name, "END")) {

    *test = (*a)->times;
  }

  else {

    (*a)->real_times = *test - (*a)->times;

    if(*inst >= (*a)->real_times) {
    (*a)->temps_inst =  (*a)->real_times;
    *inst = (*a)->temps_inst;

    }
    else {
       (*a)->temps_inst =  (*a)->real_times - *inst;
    if((*a)->frd != NULL ) {
      if(strcmp((*a)->frd->name, "END")) {
        *frd += (*a)->temps_inst;
      }
      else {

      }
   

 

    *inst  = (*a)->temps_inst;

  }

  }
   
    }
  ModifieArbre(&(*a)->frd, test, inst, frd);

}






/* BUT : Affiche un Arbre 'a'
*  Paramètres : Arbre a -> Arbre à afficher
*  Renvoi : void
*/
void afficheArbre(Arbre a) {

  if (a == NULL) {
    return;
  }
  printf("%s %f %lf\n",a->name, a->times, a->real_times);
  afficheArbre(a->fg);
  afficheArbre(a->frd);

}




/* BUT : Utilise dot 
*  Paramètres : FILE *out -> fichier de sortie
*  Renvoi : void
*/
void ecrireDebut(FILE * out){
  fprintf(out, "digraph arbre {\n");
  fprintf(out, "\tnode [shape=record,height=.1]\n");
  fprintf(out, "\tedge [tailclip=false, arrowtail=dot, dir=both];\n");
}





void ecrireArbre(FILE * out, Arbre a){


    if(a == NULL) {
        return;
    }

     
    fprintf(out, "\n");
    fprintf(out, "n%p [label= \"<gauche>  | <valeur> %s temps_fct: %f temps_cumul: %f | <droit>\"]", a, a->name, a->real_times, a->temps_inst);
          

    if(a->fg != NULL ){
      
      fprintf(out, "n%p : gauche : c -> n%p : valeur;", a, a->fg);
        
    }

    if(a->frd != NULL ){
       
        fprintf(out, "n%p : droit : c -> n%p : valeur;", a, a->frd);
        
  }

    ecrireArbre(out, a->fg);
    ecrireArbre(out, a->frd);

}

/*


void ecrireArbre(FILE * out, Arbre a){


  if(a == NULL) {
      return;
  }

  if (strcmp(a->name, "END")) {
    fprintf(out, "\n");
    fprintf(out, "n%p [label= \"<gauche>  | <valeur> %s %f %f | <droit>\"]", a, a->name,  a->temps_inst, a->real_times);
      
    

    if(a->fg != NULL && strcmp(a->fg->name, "END")){
      fprintf(out, "n%p : gauche : c -> n%p : valeur;", a, a->fg);

    }

    if(a->frd != NULL && strcmp(a->frd->name, "END")){
      fprintf(out, "n%p : droit : c -> n%p : valeur;", a, a->frd);
    }

  }

  ecrireArbre(out, a->fg);
  ecrireArbre(out, a->frd);

}
*/



/* BUT : Utilise dot 
*  Paramètres : FILE *out -> fichier de sortie
*  Renvoi : void
*/
void ecrireFin(FILE * out){
  fprintf(out, "\n}\n");
}


/* BUT : Utilise dot poure afficher un arbre
*  Paramètres : Arbre a   -> arbre à afficher
*  Renvoi : void
*/
void dessine(Arbre a){

  FILE * out;
  out = fopen("arbre.dot", "w");
  ecrireDebut(out);
  ecrireArbre(out, a);
  ecrireFin(out);
  fclose(out);
  system("dot -Tpdf arbre.dot -o arbre.pdf");
  system("evince arbre.pdf &");
}




void ConstruireTab(Arbre a, Ligne tab[], int *effectif) {
    if(a == NULL) {
        return;
    }
    /*Pas un END*/
    if (strcmp(a->name, "END")) {
    	int i;
    	printf("%s %lf\n", a->name, a->real_times);

    	for (i = 0; i < *effectif; i++) {
    		/*deja dans tab*/

    		if (!strcmp(a->name, tab[i].name)) {
    			
    			tab[i].nb_appel += 1;
    			tab[i].temps_moy += a->real_times;
    			break;
    		}
    	}
    	if (i == *effectif) {

    		tab[i].nb_appel = 1;
    	
    	tab[i].temps_moy = a->real_times;
    	tab[i].times = a->real_times;
    	strcpy(tab[i].name, a->name);
    	*effectif += 1;
    	}

    	/*Pas dans tab*/
    	
    }

    ConstruireTab(a->fg, tab, effectif);
    ConstruireTab(a->frd, tab, effectif);

} 


/*PDF calcul tronque*/
void CalculTemp_Moy(Ligne tab[], int size) {
	int i;
	for(i = 0; i < size; i++) {
		tab[i].temps_moy = tab[i].temps_moy /(double) tab[i].nb_appel;
	}
}

void AfficheTab(Ligne tab[], int size) {
  int i;
  if (tab == NULL) {
    exit(1);
  }

  printf("nom  temps    nb_appel   temps_moy \n");
  for (i = 0; i < size; i++) {
    printf("%s %lf %d  \t %lf \n",tab[i].name, tab[i].times, tab[i].nb_appel, tab[i].temps_moy);
  }

}




int CompareAppel(const void * a, const void * b) {
   /*return ( *(double*)a - *(double*)b );*/
	  Ligne* p = (Ligne*)a;
     Ligne* p2 = (Ligne*)b;
 
     return (p2->nb_appel - p->nb_appel);
}

int CompareName(const void * a, const void * b) {
   /*return ( *(double*)a - *(double*)b );*/
	  Ligne* p = (Ligne*)a;
     Ligne* p2 = (Ligne*)b;
 
     return (strcmp(p->name,p2->name));
}

int CompareTime(const void * a, const void * b) {
   /*return ( *(double*)a - *(double*)b );*/
	  Ligne* p = (Ligne*)a;
     Ligne* p2 = (Ligne*)b;
 
     return (p2->times - p->times);
}

int CompareTemp_moy(const void * a, const void * b) {
   /*return ( *(double*)a - *(double*)b );*/
	  Ligne* p = (Ligne*)a;
     Ligne* p2 = (Ligne*)b;
 
     return (p2->temps_moy - p->temps_moy);
}


void DessinRect(Arbre a, double *widht, double *height, double *x, double *y, MLV_Font* font, double ref, int couleur) {

  /*MLV_clear_window(MLV_COLOR_BLACK);*/

int z, e;
   if (a == NULL) {
    return;
  }
   if (strcmp(a->name, "END")) {

    *widht =  (WIDHT * a->real_times) /ref;
    *height = (HEIGHT * a->real_times) /ref;

     printf("%s (%lf,%lf) long %lf larg %lf \n",a->name, *x, *y, *widht, *height );
    MLV_draw_filled_rectangle(*x, *y, *widht, *height, MLV_rgba(255 -couleur, 0 +couleur, 0, 255));
      MLV_draw_rectangle(*x, *y, *widht, *height, MLV_COLOR_BLACK);

      /*Rectangle trop petit*/
      if (*height < 30) {
      	MLV_draw_text_with_font(*x, *y-10, "...", font, MLV_COLOR_WHITE);
      }
    else {
    	MLV_draw_text_with_font(*x, *y, "%s", font, MLV_COLOR_WHITE, a->name);
    }
   


    MLV_wait_mouse(&e,&z); 
     MLV_actualise_window();
     /*Ecart le  plus esthétique*/
   *x += 20;
  *y += 50;
     

  }
 
  DessinRect(a->fg, widht, height, x , y , font, ref, couleur + STEP);
  *x +=  *widht + 10;
  *y = *height +10;
  DessinRect(a->frd, widht, height, x, y, font, ref, couleur);


}


int main( int argc, char *argv[] ){

  Arbre a = NULL;
  Arbre b = NULL;
  Ligne tab[10];
  FILE *fichier;
  double test = 0;
  double inst = 0;
  double frd = 0;
  int effectif = 0;
  fichier = fopen("profile.log", "r");

  construitArbre(&a, fichier);
 

  printf("\n");
  rewind(fichier);
  construitArbre(&b, fichier);
  ModifieArbre(&b, &test, &inst, &frd);

  fclose(fichier);
  ConstruireTab(b, tab, &effectif);
  CalculTemp_Moy(tab, effectif);
  printf("-------%d\n",effectif );
  /*
  AfficheTab(tab, effectif);
  

  printf("%lf + %lf = %lf\n",tab[1].temps_moy, tab[2].temps_moy, tab[1].temps_moy+ tab[2].temps_moy );


printf("\n\n");
printf("\n\n");

qsort(tab, effectif, sizeof(Ligne), CompareAppel);
printf("Nb nb_appel\n");
AfficheTab(tab, effectif);
printf("\n\n");


qsort(tab, effectif, sizeof(Ligne), CompareName);
printf("name\n");
AfficheTab(tab, effectif);
printf("\n\n");



qsort(tab, effectif, sizeof(Ligne), CompareTime);
printf("times\n");
AfficheTab(tab, effectif);
printf("\n\n");


qsort(tab, effectif, sizeof(Ligne), CompareTemp_moy);
printf("temps_moy\n");
AfficheTab(tab, effectif);
printf("\n\n");
*/

 /*dessine(b);*/
double x, y;
/*
int deplace = 10;
int i  = 0;
int taille = 481;
int pas = 5;

int coeff = 50;*/

 MLV_create_window( "Profileur", "Profileur", WIDHT, HEIGHT);


    MLV_Font* font;

    font = MLV_load_font( "./font/DejaVuSerif-Bold.ttf" , 25);
    if (font == NULL) {
      exit(1);
    }
    /*
    MLV_draw_filled_rectangle(i * deplace , taille*i, WIDHT - i *100, HEIGHT - i *100, MLV_rgba(255 -i*pas, 0 +i*pas, 0, 255));
    MLV_draw_text_with_font(i * deplace +5 , taille*i, "%s", font, MLV_COLOR_WHITE, "main");

    i = 1;
    MLV_draw_filled_rectangle(i * deplace , 81*i, WIDHT - i *100, HEIGHT - i *100, MLV_rgba(255 -15*pas, 0 +15*pas, 0, 255));
    MLV_draw_text_with_font(i * deplace +5 , 81*i, "%s", font, MLV_COLOR_WHITE, "fact");


 i = 2;
    MLV_draw_filled_rectangle(i * deplace , 20*i, WIDHT - i *100, HEIGHT - i *100, MLV_rgba(255 -30*pas, 0 +30*pas, 0, 255));
    MLV_draw_text_with_font(i * deplace +5 , 81*i, "%s", font, MLV_COLOR_WHITE, "fact");
*/
    /*

    MLV_draw_filled_rectangle(10 , 10, 8*coeff, 10*coeff, MLV_rgba(255 -i*pas, 0 +i*pas, 0, 255));
    MLV_draw_text_with_font(i * deplace +5 , taille*i, "%s", font, MLV_COLOR_WHITE, "fact");


    MLV_draw_filled_rectangle(200+ 8*coeff , 10, 11*coeff, 10*coeff, MLV_rgba(255 -50,  50, 0, 255));
    MLV_draw_text_with_font(200+ 8*coeff , 10, "%s", font, MLV_COLOR_WHITE, "Test");

    */
/*
    MLV_draw_filled_rectangle(0 , 10, WIDHT, HEIGHT, MLV_COLOR_RED);
    MLV_draw_text_with_font(0 ,10,  "%s", font, MLV_COLOR_WHITE, "Main");


   MLV_draw_filled_rectangle(20 , 20, (WIDHT - 215)/2, HEIGHT -481, MLV_COLOR_GREEN);
    MLV_draw_text_with_font(20 , 20, "%s", font, MLV_COLOR_WHITE, "Fact");


    MLV_draw_filled_rectangle(40 , 30, (WIDHT - 215 -53)/2, HEIGHT -481 -42, MLV_COLOR_BLUE);
    MLV_draw_text_with_font(40 , 30, "%s", font, MLV_COLOR_WHITE, "Fact");



    MLV_draw_filled_rectangle((WIDHT - 215)/2 +10 , 20, (WIDHT - 284)/2, HEIGHT -227, MLV_COLOR_ORANGE);
    MLV_draw_text_with_font((WIDHT - 215)/2 + 10 , 30, "%s", font, MLV_COLOR_WHITE, "Test");


    MLV_draw_filled_rectangle((WIDHT - 284)/2 + (WIDHT - 215)/2 +10 , 20, (WIDHT - 135)/2, HEIGHT -108, MLV_COLOR_WHITE);
    MLV_draw_text_with_font((WIDHT - 215)/2 + 10 , 30, "%s", font, MLV_COLOR_WHITE, "Fact2");

*//*
    MLV_draw_filled_rectangle(0 , 10, WIDHT, HEIGHT, MLV_COLOR_RED);
    MLV_draw_text_with_font(0 ,10,  "%s", font, MLV_COLOR_WHITE, "Main");


   MLV_draw_filled_rectangle(20 , 20, 215, HEIGHT -481, MLV_COLOR_GREEN);
    MLV_draw_text_with_font(20 , 20, "%s", font, MLV_COLOR_WHITE, "Fact");


    MLV_draw_filled_rectangle(40 , 30, 215+53, HEIGHT -481 -42, MLV_COLOR_BLUE);
    MLV_draw_text_with_font(40 , 30, "%s", font, MLV_COLOR_WHITE, "Fact");



    MLV_draw_filled_rectangle((WIDHT - 215)/2 +10 , 20, 284, HEIGHT -227, MLV_COLOR_ORANGE);
    MLV_draw_text_with_font((WIDHT - 215)/2 + 10 , 30, "%s", font, MLV_COLOR_WHITE, "Test");


    MLV_draw_filled_rectangle((WIDHT - 284)/2 + (WIDHT - 215)/2 +10 , 20, (WIDHT - 135)/2, HEIGHT -108, MLV_COLOR_WHITE);
    MLV_draw_text_with_font((WIDHT - 215)/2 + 10 , 30, "%s", font, MLV_COLOR_WHITE, "Fact2");
*/
double widht = 0;
double height = 0;

DessinRect(b, &widht, &height, &x, &y, font, b->real_times, 0);


int z, r;
    /*MLV_actualise_window();*/

    MLV_wait_mouse(&z,&r);

   
    MLV_free_font(font);
    MLV_free_window();
    printf("aa (WIDHT - 284)/2 + (WIDHT - 215)/2 +10  = %d taile =%d\n", (WIDHT - 284)/2 + (WIDHT - 215)/2 +10, (WIDHT - 135)/2 );

    printf("%d %d\n",WIDHT, HEIGHT );



  return 0;

}











