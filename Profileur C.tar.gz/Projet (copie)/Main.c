/* AUTHOR : Metayer Ambre & Saouter Marion
*  Creation 15-11-2018
∗  Change  */



#include <stdio.h>
#include <stdlib.h>
#include <time.h>


/*Pour Mac*/
#ifdef __MACH__
#include <mach/clock.h>
#include <mach/mach.h>
#endif







#define BILLION 1000000000L 



#ifndef PROFILE_MODE
#define PROFILE /*Empty Macro*/

#else

#define PROFILE struct timespec start; FILE* fichier = fopen("profile.log", "a");  \
        current_utc_time(&start); \
        double accum = (start.tv_sec ) + (double)(start.tv_nsec ) / (double)BILLION; \
        fprintf(fichier, "%s -- time : %.6lfs \n",__FUNCTION__, accum);  fclose(fichier); 

#define return struct timespec stop; current_utc_time(&stop); fichier = fopen("profile.log", "a"); \
        accum = ( stop.tv_sec ) + (double)( stop.tv_nsec ) / (double)BILLION; \
        fprintf(fichier,"END -- time : %.6lfs \n", accum); \
        fclose(fichier);  \
        return

#endif







/*For Mac that does not have the function clock_gettime*/

/* Purpose : 
*  Setting :
*  Return :
*/
void current_utc_time(struct timespec *ts) {
  #ifdef __MACH__ 
    clock_serv_t cclock;
    mach_timespec_t mts;
    host_get_clock_service(mach_host_self(), CALENDAR_CLOCK, &cclock);
    clock_get_time(cclock, &mts);
    mach_port_deallocate(mach_task_self(), cclock);
    ts->tv_sec = mts.tv_sec;
    ts->tv_nsec = mts.tv_nsec;

  #else
      clock_gettime(CLOCK_REALTIME, ts);
  #endif

}







int fact (int n) {

  PROFILE
  int res;

  if (n <= 1) {
    return 1;
  }

  else {
    res = n * fact(n-1);
    return res;
  }    
}



int test(int n) {
   PROFILE
  int res;

  if (n <= 1) {
    return 1;
  }

  else {
    res = n * test(n-1);
    return res;
  }    
}




int main(int argc, char **argv, char **arge) {

  
  /*Clear the previous log if they exist*/
  FILE *fichier1 = fopen("profile.log", "w+");
  /*Ap l'ouverture de fichier sinon on écrase pas les précédant log*/
  PROFILE
  


 
  fact(10);
  /*test(3);
  fact(2);*/

  fclose(fichier1);
  return 0;
}


