/* AUTHOR : Metayer Ambre & Saouter Marion
*  Creation 15-11-2018
∗  Change  */

#ifndef PROFILE_MODE
#define PROFILE /*Empty Macro*/

#else

#include <time.h>
#define BILLION 1000000000L 

#define PROFILE struct timespec start; clock_gettime(CLOCK_REALTIME, &start); \
 		FILE* fichier = fopen("profile.log", "a");  \
        double accum = (start.tv_sec ) + (double)(start.tv_nsec ) / (double)BILLION; \
        fprintf(fichier, "%s -- time : %.6lfs \n",__FUNCTION__, accum); \
        fclose(fichier); 

#define return struct timespec stop; clock_gettime(CLOCK_REALTIME, &stop); \
        fichier = fopen("profile.log", "a"); \
        accum = ( stop.tv_sec ) + (double)( stop.tv_nsec ) / (double)BILLION; \
        fprintf(fichier,"END -- time : %.6lfs \n", accum); \
        fclose(fichier);  \
        return

#endif