/* AUTEURS : Metayer Ambre & Saouter Marion
*  Creation 23-10-2018
∗  Modification  12-11-2018*/


#include "View.h"


/* BUT : Compare x et y
*  Paramètres : int a, b -> les 2 nombres à comparer
*				int *res -> résultat de la comparaison
*  Renvoi : void
*/
static void Compare_nb(int x, int y, int *res) {
	if (x == y) {
		*res = 0;
	}
	else if (x < y) {
		*res = -1;
	}
	else {
		*res = 1;
	}
}


/* BUT : Affiche un découpage par bloc pour un image donnée
*  Paramètres : void
*  Renvoi : void
*/
static void Draw_All_Line() {
	int i, j;
	
	for (i = 0; i <= NB_LIG; i++) {
		for (j = 0; j <= NB_COL; j++) {

			/*i et j inversé dans MLV*/
			MLV_draw_line(DECALE + TAILLE_BLOC * j - 1, DECALE, DECALE + TAILLE_BLOC * j - 1, TAILLE_IMG + DECALE, MLV_COLOR_BLACK);
			MLV_draw_line(DECALE + TAILLE_BLOC * j, DECALE, DECALE + TAILLE_BLOC * j, TAILLE_IMG + DECALE, MLV_COLOR_BLACK);
			MLV_draw_line(DECALE + TAILLE_BLOC * j + 1, DECALE, DECALE + TAILLE_BLOC * j + 1, TAILLE_IMG + DECALE, MLV_COLOR_BLACK);

		}

		MLV_draw_line(DECALE, DECALE + TAILLE_BLOC * i - 1, TAILLE_IMG + DECALE, DECALE + TAILLE_BLOC * i - 1, MLV_COLOR_BLACK);
		MLV_draw_line(DECALE, DECALE + TAILLE_BLOC * i , TAILLE_IMG + DECALE, DECALE + TAILLE_BLOC * i, MLV_COLOR_BLACK);
		MLV_draw_line(DECALE, DECALE + TAILLE_BLOC * i + 1, TAILLE_IMG + DECALE, DECALE + TAILLE_BLOC * i + 1, MLV_COLOR_BLACK);
	}
}


int Show_Img(MLV_Image **img, char *titre ) {
	*img =  MLV_load_image(titre);
	if (*img == NULL) {
		fprintf(stderr, "Erreur pas d'image\n");
		return 0;
	}

	MLV_draw_image(*img, DECALE, DECALE);
	MLV_actualise_window();
	return 1;

}


void Draw_Img(Plateau *p,  MLV_Image *img) {
	int i, j;
	int x, y;
	int x_ou_cop, y_ou_cop;
	int x_quoi_cop, y_quoi_cop;

	for (i = 0; i < NB_LIG; i++) {
		for (j = 0; j < NB_COL; j++) {
			x = GetLig(p, i, j);
			y = GetCol(p, i, j);

			/*dans la MLV x et y sont inversé*/
			x_ou_cop = (TAILLE_BLOC * j) + DECALE;
			y_ou_cop = (TAILLE_BLOC * i) + DECALE;

			x_quoi_cop = (TAILLE_BLOC * y);
			y_quoi_cop = (TAILLE_BLOC * x);
			
			/*Carré noir*/
			if (x == 3 && y == 3) {
				MLV_draw_filled_rectangle(x_ou_cop, y_ou_cop, TAILLE_BLOC, TAILLE_BLOC, MLV_COLOR_BLACK);
				MLV_actualise_window();
			}

			else {
				MLV_draw_partial_image(img, x_quoi_cop , y_quoi_cop, TAILLE_BLOC, TAILLE_BLOC, x_ou_cop, y_ou_cop);
			}
		}
	}

	Draw_All_Line();
	MLV_actualise_window();
}


void Timer(int nb_coup, MLV_Font* font) {
    int temps;
    int resmin; 
    int ressec;
    int x, y;
    temps =  MLV_get_time()/1000;

    resmin = (temps/60);
    ressec = (temps)%60;
    x = TAILLE_IMG + 2 * DECALE;
    y = DECALE + (TAILLE_BLOC);

    MLV_draw_text_with_font(x, y, "Nombre de coup : %d ", font, MLV_COLOR_BLACK, nb_coup);
    MLV_draw_text_with_font(x, y + DECALE, "Temps écouler  : %d min  %d s  ", font, MLV_COLOR_BLACK, resmin, ressec);
    
    MLV_actualise_window();
    MLV_draw_text_with_font(x, y, "Nombre de coup : %d ", font, MLV_COLOR_WHITE, nb_coup);
    MLV_draw_text_with_font(x, y + DECALE, "Temps écouler  : %d min  %d s ", font, MLV_COLOR_WHITE, resmin, ressec);
}


void Animation(Carre *noir, Carre *deplace, MLV_Image *img, Plateau *p,  MLV_Font* font, int nb_coup) {
	int x_deb, y_deb;
	int x_fin, y_fin;
	int val_x, val_y;
	int i, j, k;
	
	/*x et y inverse*/
	x_deb = GetColCarre(deplace) * TAILLE_BLOC;
	y_deb = GetLigCarre(deplace) * TAILLE_BLOC;

	x_fin = GetColCarre(noir) * TAILLE_BLOC;
	y_fin = GetLigCarre(noir) * TAILLE_BLOC;

	val_x = GetCol(p, GetLigCarre(deplace), GetColCarre(deplace)) * TAILLE_BLOC;
    val_y = GetLig(p, GetLigCarre(deplace), GetColCarre(deplace)) * TAILLE_BLOC;

	Compare_nb(x_deb, x_fin, &i);
	Compare_nb(y_deb, y_fin, &j);

	for (k = 0; k < TAILLE_BLOC; k++) {
		MLV_draw_partial_image(img, val_x , val_y, TAILLE_BLOC, TAILLE_BLOC, (x_fin +DECALE) + i*k, (y_fin +DECALE) +j*k);
		Timer(nb_coup, font);
		MLV_draw_filled_rectangle((x_fin +DECALE) + i*k, (y_fin +DECALE) +j*k, TAILLE_BLOC, TAILLE_BLOC, MLV_COLOR_BLACK);
	}

	MLV_draw_partial_image(img, val_x , val_y, TAILLE_BLOC, TAILLE_BLOC, (x_fin +DECALE) + i*k, (y_fin +DECALE) +j*k);
	Draw_All_Line();

	MLV_actualise_window();
	Timer(nb_coup, font);
}


int Clic(Carre *clic, int x, int y) {
	int val = TAILLE_BLOC;

	/*Essentiel si on décale l'image pour éviter d'accepter des clic hors image en haut et à droite */
	if (x < DECALE || y < DECALE){
		return 0;
	}
	x -=DECALE;
	y -=DECALE; 
	SetLigCarre(clic, y/val);
	SetColCarre(clic, x/val);

	return 1;
}


