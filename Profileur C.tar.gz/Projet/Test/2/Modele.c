/* AUTEURS : Metayer Ambre & Saouter Marion
*  Creation 23-10-2018
∗  Modification  12-11-2018*/


#include "Modele.h"


void InitialisationPlateau(Plateau * P, Carre *noir) {
    PROFILE
    int i, j;
    for (i = 0; i < NB_LIG; i++) {
        for (j = 0; j < NB_COL; j++) {
            SetLig(P, i, j, i);
            SetCol(P, i, j, j);
        }
    }

    /*1ères coordonnées du carre noir*/
    SetColCarre(noir, 3);
    SetLigCarre(noir, 3);
    return;
}



void AffichePlateau(const Plateau *p) {
    PROFILE
    int i, j;
    int x, y;
    for (i = 0; i < NB_LIG; i++) {
        for (j = 0; j < NB_COL; j++) {
            x = (p->bloc)[i][j].col;
            y = (p->bloc)[i][j].lig;
            /*inverser x et y*/
            printf("(%d,%d) ", y, x);
        }
        printf("\n");
    }
    return;
}


void SetLigCarre(Carre *c, int i) {
    PROFILE
    c->lig = i;
    return;
}


void SetColCarre(Carre *c, int j) {
    PROFILE
    c->col = j;
    return;
}


int GetLigCarre(Carre *c) {
    PROFILE
    return c->lig;
}


int GetColCarre(Carre *c) {
    PROFILE
    return c->col;
}


void SetLig(Plateau *P, int i, int j, int val) {
    PROFILE
    ((P->bloc)[i][j].lig) = val;
    return;
}


void SetCol(Plateau *P, int i, int j, int val) {
    PROFILE
    ((P->bloc)[i][j].col) = val;
    return;
}


int GetLig(Plateau *P, int i, int j){
    PROFILE
    return ((P->bloc)[i][j].lig);
}


int GetCol(Plateau *P, int i, int j){
    PROFILE
    return ((P->bloc)[i][j].col);
}
