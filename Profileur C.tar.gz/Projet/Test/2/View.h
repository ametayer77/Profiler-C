/* AUTEURS : Metayer Ambre & Saouter Marion
*  Creation 23-10-2018
∗  Modification  12-11-2018*/

#ifndef __VIEW__
#define __VIEW__ 


#include <stdio.h>
#include <stdlib.h>
#include <MLV/MLV_all.h>

#include "include/macro_profileur.h"
#include "Modele.h"


/*Taille de la fenetre */
#define WIDHT MLV_get_desktop_width()
#define HEIGHT MLV_get_desktop_height()

/*Taille de l'image, bloc et nombre de blocs */
#define TAILLE_IMG 512
#define NB_BLOC 4
#define TAILLE_BLOC (TAILLE_IMG) / (NB_BLOC)

/*Décalage en x et y de l'image sur la fenetre, obligatoirement multiple de TAILLE_BLOC*/
#define DECALE (TAILLE_BLOC )


/* BUT : Recupère le nom d'une image et l'affiche si possible
*  Paramètres : MLV_Image **img -> image à afficher
*				char *titre     -> titre de l'image
*  Renvoi : 1 si l'image existe
*			0 sinon
*/
int Show_Img(MLV_Image **img, char *titre );


/* BUT : Affiche l'image "*img" en fonction des valeurs du plateau de jeu
*  Paramètres : Plateau *p      -> plateau de jeu
*				MLV_Image **img -> image à afficher
*  Renvoi : void
*/
void Draw_Img(Plateau *p,  MLV_Image *img);


/* 
* BUT : Gère le timer (initialisation, affichage)
* Paramètres : int nb_coup		-> nombre de coups joués actuellement
*              MLV_Font* font 	-> police de caractère pour afficher l'état actuel du timer
*/
void Timer(int nb_coup,  MLV_Font* font);


/* BUT : Déplace sur la fenetre MLV le bloc "noir" vers le bloc "deplace"
*  Paramètres : Carre *noir  -> coordonnées du carré à noir
*				Care *deplace -> coordonnées du carré à déplacer
*				MLV_Image *img -> image à afficher
*				Plateau *p      -> plateau de jeu
*				MLV_Font* font  -> Police du texte à afficher
*				int nb_coup     -> nombre de coups valides
*  Renvoi : void
*/
void Animation(Carre *noir, Carre *deplace, MLV_Image *img, Plateau *p, MLV_Font* font, int nb_coup);


/* BUT : Attend un clic du joueur, puis stocke ses coordonnées dans "*clic" si il est valide
*  Paramètres : Carre *clic  -> coordonnées du carré cliqué
*				int x, y     -> coordonnées du clic dans la fenetre
*  Renvoi : 1 si le clic est en-dessous du coin supérieur gauche de l'image
*			0 sinon
*/
int Clic(Carre *clic, int x, int y);

#endif












