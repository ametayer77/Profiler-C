/* AUTEURS : Metayer Ambre & Saouter Marion
*  Creation 23-10-2018
∗  Modification  12-11-2018*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <MLV/MLV_all.h>


#include "include/macro_profileur.h"
#include "Modele.h"
#include "View.h"
#include "Jeu.h"


/* BUT : Initialise la fenetre MLV pour pouvoir jouer au Taquin
*  Paramètres : Plateau *p     -> plateau de jeu
*               Carre *noir    -> coordonnées du carré noir
*               MLV_Image *img -> image à afficher
*               char *titre    -> nom de l'image
*  Renvoie : void
*/
void Init_Jeu (Plateau *p, Carre *noir, MLV_Image** img, char *titre) {
    PROFILE
    Carre deplace;
    MLV_Sound* init_game = NULL;
    MLV_Font* font = NULL;
    MLV_Image* img_petit = NULL;

    MLV_create_window("Taquin", "Taquin", WIDHT, HEIGHT);
    MLV_clear_window(MLV_COLOR_WHITE);

    *img =  MLV_load_image(titre);
    font = MLV_load_font( "./font/DejaVuSerif-Bold.ttf" , 30);
    if (*img == NULL) {
        fprintf(stderr, "Erreur pas d'image valide programme terminé\n");
        exit(1);
    }

    if(MLV_init_audio() == 0){
        init_game = MLV_load_sound("Sons/init_game.wav");
    }

    InitialisationPlateau(p, noir);

    img_petit = MLV_load_image("lena.jpg");
    MLV_resize_image_with_proportions(img_petit, TAILLE_IMG/2, TAILLE_IMG/2);
    MLV_draw_image(img_petit, 2* DECALE +  TAILLE_IMG , TAILLE_IMG + DECALE);


    Melange(&deplace, noir, p);
    Draw_Img(p,  *img);
    

    Timer(0, font);
    MLV_play_sound(init_game, 0.5);
    MLV_actualise_window();
    MLV_wait_milliseconds(900);

    MLV_free_sound(init_game);
    MLV_free_font(font);
    return;
}


/* BUT : Joue au jeu du Taquin 
*  Paramètres : Plateau *p     -> plateau de jeu
*               Carre *noir    -> coordonnées du carré noir
*               MLV_Image *img -> image à afficher
*  Renvoi : void
*/
void Jeu (Plateau *p, Carre *noir, MLV_Image* img) {
    PROFILE
    Carre clic;
    int res, nb_coup = 0;
    int x, y, rep = 0;
    int x1, y1;
    MLV_Font* font = NULL;
    MLV_Sound* clic_hors_grille = NULL;
    MLV_Sound* fin_game = NULL;


    font = MLV_load_font( "./font/DejaVuSerif-Bold.ttf" , 30);
    x = TAILLE_IMG + 2 * DECALE;
    y = DECALE + (TAILLE_IMG / 2);

    Timer(nb_coup, font);
    if(MLV_init_audio() == 0){
        clic_hors_grille = MLV_load_sound("Sons/clic_hors_grille.wav");
        fin_game = MLV_load_sound("Sons/fin_game.wav");
    }

    while (Fin_de_jeu(p) != 1) {
        while(rep != 1){
            rep = MLV_wait_mouse_or_seconds(&x1, &y1, 1);
            Timer(nb_coup, font);
        }

        res = Clic(&clic, x1, y1);
        rep = 0;
        
        if (res == 1 && Clic_valide(&clic, noir) == 1) {
            nb_coup += 1;
            Swap(&clic, noir, p);
            Animation(noir, &clic, img, p, font, nb_coup);            
        }

        else {
            MLV_play_sound(clic_hors_grille, 0.5);
        }
    }

    MLV_draw_text_with_font(x, y + DECALE, "Partie terminé", font, MLV_COLOR_BLACK);
    Timer(nb_coup, font);
    MLV_play_sound(fin_game, 0.5);
    MLV_wait_mouse(&x, &y);
   
   
    MLV_free_sound(clic_hors_grille);
    MLV_free_sound(fin_game);
    MLV_free_font(font);
    MLV_free_window();
    return;
}



int main(int argc, char *argv[] ) {
    PROFILE
    MLV_Image* img = NULL;
    Plateau p;
    Carre noir;

    srand(time(NULL));
    Init_Jeu(&p, &noir, &img, "lena.jpg");
    
    MLV_actualise_window();

    Jeu (&p, &noir, img);
    
    return 0;
}











