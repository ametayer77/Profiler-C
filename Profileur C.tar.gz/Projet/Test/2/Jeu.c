/* AUTEURS : Metayer Ambre & Saouter Marion
*  Creation 23-10-2018
∗  Modification  12-11-2018*/

#include <MLV/MLV_all.h>
#include "Jeu.h"


/* BUT : Vérifie que x est compris entre 0 et NB_COL, avec NB_COL et NB_LIG égaux
*  Paramètres : int x -> nombre à vérifier
*  Renvoi : 1 si 0 <= x < NB_COL
*           0 sinon
*/
static int Verif_Grille(int x) {
    PROFILE
    if (x < 0) {
        return 0;
    }

    if (x >= NB_COL || x >= NB_LIG) {
        return 0;
    }

    return 1;
}


/* BUT : Calcule la valeur absolue de (x - y) et place cette valeur dans "*res"
*  Paramètres : int x, y -> nombres 
*               int *res -> valeur absolue
*  Renvoi : void
*/
static void Val_Abs(int x, int y, int *res) {
    PROFILE
    *res = x - y;

    if (*res < 0) {
        *res = -(*res);
    }
    return;
}


/* BUT : Vérifie que le carré cliqué par le joueur est valide (à coté du carré noir, le clic est dans la grille)
*  Paramètres : Carre *clic  -> coordonnées du carré cliquer
*               Carre *noir -> coordonnées du carré noir
*  Renvoi : 1 clique valide
*           0 sinon
*/
static int Verif_Possible(Carre *clic, Carre *noir) {
    PROFILE
    int x_c, y_c;
    int x_n, y_n;
    int res_x, res_y;

    x_c = GetLigCarre(clic);
    y_c = GetColCarre(clic);

    x_n = GetLigCarre(noir);
    y_n = GetColCarre(noir);

    /*Clic 1 et 2 sur le carré noir*/
    if (x_c == x_n && y_c == y_n) {
        return 0;
    }

    Val_Abs(x_c, x_n, &res_x);
    Val_Abs(y_c, y_n, &res_y);

    /*Clic en diagonale */
    if (res_x == res_y) {
        return 0;
    }

    /*Clic a plus d'une case du carré noir*/
    if (res_x > 1 || res_y > 1) {
        return 0;
    }

    return 1;
}


/* BUT : Echange les coordonées du carré "*un" avec celui du carré "*deux"
*  Paramètres : Carre *un, *deux  -> coordonnées des carrés à échanger 
*  Renvoi : void
*/
static void Swap_aux(Carre *un, Carre *deux) {
    PROFILE
    Carre tmp;

    SetLigCarre(&tmp,GetLigCarre(un));
    SetColCarre(&tmp,GetColCarre(un));

    SetLigCarre(un,GetLigCarre(deux));
    SetColCarre(un,GetColCarre(deux));

    SetLigCarre(deux,GetLigCarre(&tmp));
    SetColCarre(deux,GetColCarre(&tmp));
    return;
}


void Swap(Carre *clic, Carre *noir, Plateau *p) {
    PROFILE
    int val_x, val_y;

    val_x = GetLig(p, GetLigCarre(clic),GetColCarre(clic));
    val_y = GetCol(p, GetLigCarre(clic),GetColCarre(clic));
   
    SetLig(p, GetLigCarre(clic), GetColCarre(clic), 3);
    SetCol(p, GetLigCarre(clic), GetColCarre(clic), 3);

    SetLig(p, GetLigCarre(noir), GetColCarre(noir), val_x);
    SetCol(p, GetLigCarre(noir), GetColCarre(noir), val_y);

    Swap_aux(clic, noir);
    return;   
}


int Clic_valide(Carre *clic, Carre *noir) {
    PROFILE
    int x, y;
    
    x = GetLigCarre(clic);
    y = GetColCarre(clic);

    if (Verif_Grille(x) == 0 || Verif_Grille(y) == 0) {
        return 0;
    }

    if (Verif_Possible(clic, noir) == 0) {
        return 0;
    }
     
    return 1;
}


void Melange(Carre *clic, Carre *noir, Plateau *p) {
    PROFILE
    int tab[] = {-1, 0, 1};
    int x, y;
    int i = 0;

    while (i < NB_PERMU) {
        x = rand()%3;
        y = rand()%3;
        SetLigCarre(clic, GetLigCarre(noir) + tab[x]);
        SetColCarre(clic, GetColCarre(noir) + tab[y]);

        if (Clic_valide(clic, noir) == 1) {
            Swap(clic, noir, p);
            i += 1;
        }
    }
    return;
}


int Fin_de_jeu(Plateau *p) {
    PROFILE
    int i, j;
    int x, y;

    for (i = 0; i < NB_LIG; i++) {
        for (j = 0; j < NB_COL; j++) {

            x = GetLig(p, i, j);
            y = GetCol(p, i, j);

            if (x != i || y != j) {
                return 0;
            }
        }
    }
    return 1;
}






