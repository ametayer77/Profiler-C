/* AUTEURS : Metayer Ambre & Saouter Marion
*  Creation 23-10-2018
∗  Modification  12-11-2018*/


#ifndef __MODELE__
#define __MODELE__ 

#include <stdio.h>
#include <stdlib.h>
#include "include/macro_profileur.h"
/*Nombre de ligne et de colonne dans la grille*/
#define NB_COL 4
#define NB_LIG 4


/*Structure permettant de déclarrer un Carre par sa ligne et sa colonne
Paramètre : int lig -> ligne du carré
*           int col -> colonne du carré
*/
typedef struct carre {
	int lig;
	int col;
} Carre;


/*Structure permettant de déclarer un Plateau de jeu
Paramètre : Carre bloc[NB_COL][NB_LIG] -> tableau de Carre à deux dimensions
*/
typedef struct plateau {
	Carre bloc[NB_COL][NB_LIG];
} Plateau;


/* BUT : Initialise le plateau de jeu avant le mélange, le carré noir est toujours en position (3,3) au début
*  Paramètres : Plateau *P   -> plateau de jeu 
*  				Carre *noir -> coordonnées du carré noir
*				
*  Renvoi : void
*/
void InitialisationPlateau(Plateau * P, Carre *noir);


/* BUT : Affiche le plateau de jeu actuel
*  Paramètres : const Plateau *p   -> plateau de jeu 
*				
*  Renvoi : void
*/
void AffichePlateau(const Plateau *p);


/* BUT : Affecte la valeur "i" de la ligne du carré "*c"
*  Paramètres : Carre *c -> ligne du carré à modifier
*				int i    -> valeur à affecter à la ligne
*				
*  Renvoi : void
*/
void SetLigCarre(Carre *c, int i);


/* BUT : Affecte la valeur "i" de la colonne du carré "*c"
*  Paramètres : Carre *c -> colonne du carré à modifier
*				int i    -> valeur à affecter à la colonne
*				
*  Renvoi : void
*/
void SetColCarre(Carre *c, int i);


/* BUT : Récupère la valeur de la ligne du carré "*c"
*  Paramètres : Carre *c -> ligne du carré à récupèrer
*				
*  Renvoi : valeur de la ligne
*/
int GetLigCarre(Carre *c);


/* BUT : Récupère la valeur de la colonne du carré "*c"
*  Paramètres : Carre *c -> colonne du carré à récupèrer
*				
*  Renvoi : valeur de la colonne
*/
int GetColCarre(Carre *c);


/* BUT : Affecte la valeur "val" à la ligne du bloc se trouvant en position (i,j)
*  Paramètres : Plateau *P -> plateau de jeu
*				int i, j   -> coordonées du bloc à modifier
*				int val    -> valeur à affecter la ligne
*				
*  Renvoi : void
*/
void SetLig(Plateau *P, int i, int j, int val);


/* BUT : Affecte la valeur "val" à la colonne du bloc se trouvant en position (i,j)
*  Paramètres : Plateau *P -> plateau de jeu
*				int i, j   -> coordonées du bloc à modifier
*				int val    -> valeur à affecter la colonne
*				
*  Renvoi : void
*/
void SetCol(Plateau *P, int i, int j, int val);


/* BUT : Récupère la valeur de la ligne du bloc se trouvant en position (i,j)
*  Paramètres : Plateau *P -> plateau de jeu
*				int i, j   -> coordonées du bloc à récupèrer
*				
*  Renvoi : valeur de la ligne en (i,j)
*/
int GetLig(Plateau *P, int i, int j);


/* BUT : Récupère la valeur de la colonne du bloc se trouvant en position (i,j)
*  Paramètres : Plateau *P -> plateau de jeu
*				int i, j   -> coordonées du bloc à récupèrer
*				
*  Renvoi : valeur de la colonne en (i,j)
*/
int GetCol(Plateau *P, int i, int j);

#endif



