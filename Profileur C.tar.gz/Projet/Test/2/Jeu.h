/* AUTEURS : Metayer Ambre & Saouter Marion
*  Creation 23-10-2018
∗  Modification  12-11-2018*/

#ifndef __JEU__
#define __JEU__ 


#include <stdio.h>
#include <stdlib.h>
#include <MLV/MLV_all.h>


#include "Modele.h"
#include "include/macro_profileur.h"

/* Nombre de fois qu'on mélange le plateau */
#define NB_PERMU 120


/* BUT : Echange sur le plateau les coordonées du carré "*clic" avec celuis du carré "*noir", le carré 
*		 "*clic" est obligatoirement valide 
*  Paramètres : Carre *clic, *noir  -> coordonnées des carrés à échanger
*				Plateau *p 			 -> plateau de jeu 
*  Renvoi : void
*/
void Swap(Carre *clic, Carre *noir, Plateau *p);


/* BUT : Vérifie que le carré cliqué par le joueur est possible et valide (à coté du carré noir, dans l'image)
*  Paramètres : Carre *clic  -> coordonnées du carré cliquer
*               Carre *noir -> coordonnées du carré noir
*  Renvoi : 1 clique valide
*           0 sinon
*/
int Clic_valide(Carre *clic, Carre *noir);


/* BUT : Mélange les carré du taquin par un nombre paire de permutation valides
*  Paramètres : Carre *clic, *noir  -> coordonnées des carrés à échanger
*				Plateau *p 			 -> plateau de jeu 
*  Renvoi : void
*/
void Melange(Carre *clic, Carre *noir, Plateau *p);


/* BUT : Vérifie si la partie est terminée
*  Paramètres : Plateau *p -> plateau de jeu 
*  Renvoi : 1 si la partie est terminée
*           0 sinon
*/
int Fin_de_jeu(Plateau *p);


#endif






