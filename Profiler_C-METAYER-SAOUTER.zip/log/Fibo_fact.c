#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "../include/macro_profiler.h"


int fact (int n) {

  PROFILE
  int res;

  if (n <= 1) {
    return 1;
  }

  else {
    res = n * fact(n-1);
    return res;
  }    
}



int fibo(int n) {
  PROFILE
  int res;
  if( n == 0) {
    return 0;
  }
  if( n == 1) {
    return 1;
  }
  res = fibo(n-1) + fibo(n-2);
  return res;
}




int main(int argc, char **argv, char **arge) {
  /*Efface le précédent fichier log s'il existe*/
  FILE *fichier1 = fopen("profile.log", "w+");
  /*Après l'ouverture de fichier sinon on écrase pas les précédents log*/
  PROFILE
  
  fibo(3);
  fact(3);
  fclose(fichier1);
  return 0;
}


