var searchData=
[
  ['dot_2ec',['Dot.c',['../_dot_8c.html',1,'']]]
];
