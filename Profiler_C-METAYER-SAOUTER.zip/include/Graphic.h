/** 
*	\file Arbre.c
*	\author Ambre METAYER & Marion SAOUTER
*	\brief Module pour créer l'arbre d'appels
*	\date 11 janvier 2019
**/


#ifndef __Graphic__
#define __Graphic__ 


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <MLV/MLV_all.h>


#include "Arbre.h"

/**	\struct Rectangle
*	\brief Sauvegarde les coordonnées pour tracer un rectangle sur la fenetre MLV.
*	
*	Un Rectangle connait sa largeur (width), sa hauteur (height) et les coordonnées de son coin
*	supérieur gauche (x,y).
**/
typedef struct {
	int width; 
	int height;
	int x;
	int y;
} Rectangle;


/**	\def WIDTH MLV_get_desktop_width()
*	\brief Largeur maximale de la fenetre.
**/
#define WIDTH MLV_get_desktop_width()

/**	\def HEIGHT MLV_get_desktop_height()
*	\brief Hauteur maximale de la fenetre.
**/
#define HEIGHT MLV_get_desktop_height()

/** \fn void Graphic(Arbre a)
*	\brief Appelle les différentes fonctions nécessaires pour l'affichage graphique.
*	\param Arbre a 	-> Arbre de profilage à afficher graphiquement.
*	\return void
**/
void Graphic(Arbre a);



#endif