/* AUTEURS : Metayer Ambre 
*  Creation 09-10-2018
∗  Modification  22-10-2018*/


#ifndef __Arbre__
#define __Arbre__ 

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>



/** \struct noeud
*   \brief Structure permettant de déclarer un arbre fils gauche - frere droit.
*
*   Chaque noeud sauvegarde le temps brut en milisecondes, le nom de la fonction
*   qu'il représente, le temps que la fonction mets à s'éxécuter et le temps cumulé
*   d'exécution de la fonction et de celles de ses fils.
**/
typedef struct noeud {
  double times;
  char name[BUFSIZ];
  double real_times;
  double temps_inst;
  struct noeud *fg;
  struct noeud *frd;
}Noeud, *Arbre;


/**	\struct Ligne
*	\brief Structure permettant de déclarer un tableau qui sauvegarde un arbre de profilage.
*	
*	Chaque Ligne enregistre le temps mis par une fonction à s'exécuter, le nom de la fonction,
*	le nombre de fois que la fonction est appelée et le temps moyen d'exécution de la fonction.
*
*	Une Ligne est remplie grace à l'arbre de profilage.
**/
typedef struct {
  double times;
  char name[BUFSIZ];
  int nb_appel;
  double temps_moy;
}Ligne;


/** \fn void GenerationArbre(Arbre *a, FILE *fichier)
*   \brief Construire un arbre à partir d'un fichier '*fichier'
*   \param Arbre *a      -> Arbre à construire
*          FILE *fichier -> fichier pour construire l'arbre
*  \return void
**/
void GenerationArbre(Arbre *a, FILE *fichier);

/** NOM : int hauteur(Arbre a) 
*   BUT : Calclue la hauteur de l'Arbre a
*   PARAMETRES : Arbre a           -> arbre dont on doit calculer la hauteur
*   RETOUR :  renvoie la hauteur de l'arbre
**/	
int hauteur(Arbre a);

/** \fn void afficheArbre(Arbre a)
*   \brief Afficher un arbre.
*   \param Arbre *a      -> Arbre à construire
*   \return void
**/
void afficheArbre(Arbre a);

/** \fn void Generation_Tab(Arbre a, Ligne tab[], int *effectif)
*   \brief Construit un tableau récapitulatif à partir d'un arbre.
*   \param Arbre *a      -> Arbre à construire
*          Ligne tab[]   ->
*          int *effectif ->
*   \return void
**/
void Generation_Tab(Arbre a, Ligne tab[], int *effectif);

/** \fn void afficheTab(Ligne tab[], int size)
*   \brief Afficher un tableau.
*   \param Ligne tab[]   -> Tableau à afficher
*          int size      -> Taille du tableau
*   \return void
**/
void AfficheTab(Ligne tab[], int size);

/** \fn void Lect_fichier(int argc, char *argv[], Arbre *a, int *effectif)
*	\brief Ouvre le fichier passé en argument et vérifie que l'ouverture
*	s'est passée sans souci.
*	\param 	int argc		-> nombre d'arguments en ligne de commande
*			char *argv[]	-> liste des arguments en ligne de commande
*			Arbre *a 		-> l'arbre à générer
*			int effectif	-> sauvegarde du nombre de fonctions entrées dans l'arbre
*	\return	void
**/
void Lect_fichier(int argc, char *argv[], Arbre *a, int *effectif);

/**	\fn void Tri(int num_option, Ligne *tab, int effectif)
*	\brief Tri le tableau passé en paramètre selon le num_option passé en paramètre
*	Cette fonction n'est lancée que si le profileur est lancé avec une otion de tri 
*	en ligne de commande.
*	\param int num_option	-> numéro de l'option de tri
*		   Ligne *tab 		-> tableau à trier
*		   int effectif		-> nombre d'élément du tableau à trier
*	\return void
**/
void Tri(int num_option, Ligne *tab, int effectif);


#endif






