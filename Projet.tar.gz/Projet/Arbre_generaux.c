/* AUTHOR : Metayer Ambre & Saouter Marion
*  Creation 15-11-2018
∗  Change  */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>




/* Structure permettant de déclarer un type d'arbre */
typedef struct noeud {
  double times;
  char name[BUFSIZ];
  struct noeud *fg;
  struct noeud *frd;
}Noeud, *Arbre;



typedef struct {
  double times;
  char name[BUFSIZ];
  int nb_appel;
  double temps_moy;
  double temps_inst;
}Ligne;



/* BUT : Alloue un noeud d'un Arbre
*  Paramètres : int val -> étiquette du noeud
*  Renvoi : un pointeur sur un noeud
*/
Arbre AlloueNoeud(double times, char name[]) {

    Arbre tmp;
    tmp = (Arbre)malloc(sizeof(Noeud));

    if (tmp != NULL) {
        tmp->times = times;
        strcpy(tmp->name, name);
        tmp->fg = NULL;
        tmp->frd = NULL;
        
    }
    return tmp;
}





/* BUT : Construire un arbre à partir d'un fichier '*fichier'
*  Paramètres : Arbre *a      -> Arbre à construire
*               FILE *fichier -> fichier texte
*  Renvoi : le nombre de noeud qui à 2 fils
*/
Arbre construitArbre(Arbre *a, FILE *fichier) {


  double times;
  char name[50];


    while(fscanf(fichier, "%s %*s %*s %*s %lf %*s",name, &times ) != EOF ) {
    	
    	(*a) = AlloueNoeud(times, name);
        construitArbre(&((*a)->fg), fichier);
        construitArbre(&((*a)->frd), fichier);
    }

  return *a;

}


/* BUT : Affiche un Arbre 'a'
*  Paramètres : Arbre a -> Arbre à afficher
*  Renvoi : void
*/
void afficheArbre(Arbre a) {

  if (a == NULL) {
    return;
  }
  printf("%s %f \n",a->name, a->times);
  afficheArbre(a->fg);
  afficheArbre(a->frd);

}




/* BUT : Utilise dot 
*  Paramètres : FILE *out -> fichier de sortie
*  Renvoi : void
*/
void ecrireDebut(FILE * out){
  fprintf(out, "digraph arbre {\n");
  fprintf(out, "\tnode [shape=record,height=.1]\n");
  fprintf(out, "\tedge [tailclip=false, arrowtail=dot, dir=both];\n");
}



/* BUT : Utilise dot pour afficher l'arbre a
*  Paramètres : FILE *out -> fichier de sortie
*       Arbre a   -> arbre à afficher
*  Renvoi : void
*/
void ecrireArbre(FILE * out, Arbre a){


    if(a == NULL) {
        return;
    }


    if(a->fg == NULL ){
        fprintf(out, "\n");
        fprintf(out, "n%p [label= \"<gauche>  | <times> %f | <droit>\"]", a, a->times);
        fprintf(out, "n%p : droit : c -> n%p : times;", a, a->frd);
        return;
    }

    if (a->frd != NULL) {
        
    }

    /*
    if(a->fg == NULL && a->frd == NULL){
        fprintf(out, "\n");
        fprintf(out, "n%p [label= \"<gauche>  | <times> %f | <droit>\"]", a, a->times);
        fprintf(out, "n%p : gauche : c -> n%p : times;", a, a->fg);
        return;
    }

    if(a->fg != NULL && a->frd == NULL){
        fprintf(out, "\n");
        fprintf(out, "n%p [label= \"<gauche>  | <times> %f | <droit>\"]", a, a->times);
        fprintf(out, "n%p : gauche : c -> n%p : times;", a, a->fg);
        

    }

    if(a->frd != NULL && a->fg == NULL){
        fprintf(out, "\n");
        fprintf(out, "n%p [label= \"<gauche>  | <times> %f | <droit>\"]", a, a->times);
        fprintf(out, "n%p : droit : c -> n%p : times;", a, a->frd);
        

    }

    if(a->fg != NULL && a->frd != NULL){
        fprintf(out, "\n");
        fprintf(out, "n%p [label= \"<gauche>  | <times> %f | <droit>\"]", a, a->times);
        fprintf(out, "n%p : gauche : c -> n%p : times;", a, a->fg);
        fprintf(out, "n%p : droit : c -> n%p : times;", a, a->frd);
        
    }
    */

    ecrireArbre(out, a->fg);
    ecrireArbre(out, a->frd);



}


/* BUT : Utilise dot 
*  Paramètres : FILE *out -> fichier de sortie
*  Renvoi : void
*/
void ecrireFin(FILE * out){
  fprintf(out, "\n}\n");
}


/* BUT : Utilise dot poure afficher un arbre
*  Paramètres : Arbre a   -> arbre à afficher
*  Renvoi : void
*/
void dessine(Arbre a){

  FILE * out;
  out = fopen("arbre.dot", "w");
  ecrireDebut(out);
  ecrireArbre(out, a);
  ecrireFin(out);
  fclose(out);
  system("dot -Tpdf arbre.dot -o arbre.pdf");
  system("evince arbre.pdf &");
}





void construitTab(Arbre a, Ligne *tab, int size, int i, double tmp) {
	if (a == NULL) {
    return;
  }
/*
  if (tab == NULL) {
  	
  	tab = (Ligne*)malloc(sizeof(Ligne)*size);
  	if (tab == NULL) {
  		exit(1);

  	}

  	for (i = 0; i < 4; i++) {
  		tab[i] = (char*)malloc(sizeof(char));

  	}
  }*
  */
  
  /*printf("%s %f \n",a->name, a->times);*/
  
  construitTab(a->fg, tab, size, i+1, tmp);
  strcpy(tab[i].name, a->name);
  tab[i].nb_appel = 1;
  
  construitTab(a->frd, tab, size, i, tmp);
  tmp = a->times;
  printf("%lf z=et %s \n",tmp, tab[i].name );
}



void AfficheTab(Ligne *tab, int size) {
  int i;
  if (tab == NULL) {
    exit(1);
  }
  for (i =0; i < size; i++) {
    printf("%s %lf %d\n",tab[i].name, tab[i].times, tab[i].nb_appel );
  }

}



int main( int argc, char *argv[] ){

    Arbre a = NULL;
    
    FILE *fichier1 = fopen("profile.log", "r");
    construitArbre(&a, fichier1);
    afficheArbre(a);
    Ligne *tab = NULL;


    
    tab = (Ligne*)malloc(sizeof(Ligne)*5);
    if (tab == NULL) {
      exit(1);

    }


    construitTab(a, tab, 5, 0, 0);

    printf("fjfjfj\n");
    AfficheTab(tab, 5);

    /*dessine(a);*/
    /*
    char name[50] = "main";
    char times[50] = "1564654";


     char name2[50] = "mai455n";
    char times2[50] = "77";

    char **tab = (char**)malloc(sizeof(char*)*4);
    for( i = 0; i < 4; i++) {
    	tab[i] = (char*)malloc(sizeof(char)*2);
    }


    for (i =0; i < 4; i++) {
    	for ( j=0; j < 2; j++) {
    		tab[i][j] = "454";
    		printf("%s\n",tab[i][j] );
    	}
    }
    */


    return 0;

}











