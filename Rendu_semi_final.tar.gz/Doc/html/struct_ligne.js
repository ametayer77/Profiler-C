var struct_ligne =
[
    [ "name", "struct_ligne.html#af4d105d29bbf606d5b33497f6be81f69", null ],
    [ "nb_appel", "struct_ligne.html#a5a9d4303992d7d88b9f9b2e933166e24", null ],
    [ "temps_moy", "struct_ligne.html#ae0deb5723f620eec256a5483af951b30", null ],
    [ "times", "struct_ligne.html#a4677597b9f9fc096bfb14dc3d3e9f5ea", null ]
];