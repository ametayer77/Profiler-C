/** 
* \file Dot.c
* \author Ambre METAYER & Marion SAOUTER
* \brief Module pour utiliser dot (représentation d'arbres en graphique).
* \date 11 janvier 2019
**/
#include "../include/Dot.h"



/** \fn static void ecrireDebut(FILE * out)
*  \brief Commence la génération de l'arbre
*  \param FILE *out -> fichier de sortie
*  \return void
**/
static void ecrireDebut(FILE * out){
  PROFILE
  fprintf(out, "digraph arbre {\n");
  fprintf(out, "\tnode [shape=record,height=.1]\n");
  fprintf(out, "\tedge [tailclip=false, arrowtail=dot, dir=both];\n");
  return;
}



/*

static void ecrireArbre(FILE * out, Arbre a){


    if(a == NULL) {
        return;
    }

     
    fprintf(out, "\n");
    fprintf(out, "n%p [label= \"<gauche>  | <valeur> %s temps_fct: %f temps_cumul: %f | <droit>\"]", a, a->name, a->real_times, a->temps_inst);
          

    if(a->fg != NULL ){
      
      fprintf(out, "n%p : gauche : c -> n%p : valeur;", a, a->fg);
        
    }

    if(a->frd != NULL ){
       
        fprintf(out, "n%p : droit : c -> n%p : valeur;", a, a->frd);
        
  }

    ecrireArbre(out, a->fg);
    ecrireArbre(out, a->frd);

}
*/



/** \fn static void ecrireArbre(FILE * out, Arbre a)
*  \brief Ecrit dans l'arbre graphique les infos de chaque noeud
*  \param FILE *out -> fichier de sortie
*         Arbre a   -> Arbre à copier
*  \return void
**/
static void ecrireArbre(FILE * out, Arbre a){
  PROFILE

  if(a == NULL) {
      return;
  }

  if (strcmp(a->name, "END")) {
    fprintf(out, "\n");
    fprintf(out, "n%p [label= \"<gauche>  | <valeur> %s tmp_fct %f  tmp_cumul %f | <droit>\"]", a, a->name,  a->temps_inst, a->real_times);
      
    

    if(a->fg != NULL && strcmp(a->fg->name, "END")){
      fprintf(out, "n%p : gauche : c -> n%p : valeur;", a, a->fg);

    }

    if(a->frd != NULL && strcmp(a->frd->name, "END")){
      fprintf(out, "n%p : droit : c -> n%p : valeur;", a, a->frd);
    }

  }

  ecrireArbre(out, a->fg);
  ecrireArbre(out, a->frd);
  return;

}




/** \fn static void ecrireFin(FILE * out)
* \brief Termine la génération de l'arbre
*  \param FILE *out -> fichier de sortie
*  \return void
**/
static void ecrireFin(FILE * out){
  PROFILE
  fprintf(out, "\n}\n");
  return;
}


void dessine(Arbre a){
  PROFILE
  FILE * out;
  out = fopen("arbre.dot", "w");
  ecrireDebut(out);
  ecrireArbre(out, a);
  ecrireFin(out);
  fclose(out);
  system("dot -Tpdf arbre.dot -o arbre.pdf");
  system("evince arbre.pdf &");
  return;
}  