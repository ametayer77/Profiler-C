/* AUTHOR : Metayer Ambre & Saouter Marion
*  Creation 15-11-2018
∗  Change  */



#include "../include/Arbre.h"


/* BUT : Alloue un noeud d'un Arbre
*  Paramètres : int val -> étiquette du noeud
*  Renvoi : un pointeur sur un noeud
*/
static Arbre AlloueNoeud(double times, char name[]) {

    Arbre tmp;
    tmp = (Arbre)malloc(sizeof(Noeud));

    if (tmp != NULL) {
        tmp->times = times;
        strcpy(tmp->name, name);
        tmp->fg = NULL;
        tmp->frd = NULL;
        tmp->real_times = 0;
        tmp->temps_inst = 0;
        
    }
    return tmp;
}




void construitArbre(Arbre *a, FILE *fichier) {


  double times;
  char name[50];


    if(fscanf(fichier, "%s %*s %*s %*s %lf %*s",name, &times ) != EOF ) {
      (*a) = AlloueNoeud(times, name);
      if (strcmp(name, "END")) {

        construitArbre(&((*a)->fg), fichier);
        construitArbre(&((*a)->frd), fichier);
        return;
        
      }

      
    }
}



int hauteur(Arbre a) {

    int hg;
    int hd;

    if (a == NULL) {
        return 0;
    }

    hg = hauteur(a->fg);
    hd = hauteur(a->frd);
    


    return 1 + hd + hg;
}





double  ModifieArbre(Arbre *a, double *test, double *inst, double *frd) {

  double tmp;
  if (*a == NULL) {

    return 0;

  }

  tmp = ModifieArbre(&(*a)->fg, test, inst, frd);

  if (!strcmp((*a)->name, "END")) {
    *test = (*a)->times;
    return 0;
  }

  (*a)->real_times = *test - (*a)->times;
  (*a)->temps_inst = (*a)->real_times - tmp; 
  tmp = ModifieArbre(&(*a)->frd, test, inst, frd);
  return (*a)->real_times + tmp;

}





/* BUT : Affiche un Arbre 'a'
*  Paramètres : Arbre a -> Arbre à afficher
*  Renvoi : void
*/
void afficheArbre(Arbre a) {

  if (a == NULL) {
    return;
  }
  printf("%s %f %lf\n",a->name, a->times, a->real_times);
  afficheArbre(a->fg);
  afficheArbre(a->frd);

}





void ConstruireTab(Arbre a, Ligne tab[], int *effectif) {
    if(a == NULL) {
        return;
    }
    /*Pas un END*/
    if (strcmp(a->name, "END")) {
    	int i;

    	for (i = 0; i < *effectif; i++) {
    		/*deja dans tab*/

    		if (!strcmp(a->name, tab[i].name)) {
    			
    			tab[i].nb_appel += 1;
    			tab[i].temps_moy += a->real_times;
    			break;
    		}
    	}
    	if (i == *effectif) {

    		tab[i].nb_appel = 1;
    	
    	tab[i].temps_moy = a->real_times;
    	tab[i].times = a->real_times;
    	strcpy(tab[i].name, a->name);
    	*effectif += 1;
    	}

    	/*Pas dans tab*/
    	
    }

    ConstruireTab(a->fg, tab, effectif);
    ConstruireTab(a->frd, tab, effectif);

} 


/*PDF calcul tronque*/
void CalculTemp_Moy(Ligne tab[], int size) {
	int i;
	for(i = 0; i < size; i++) {
		tab[i].temps_moy = tab[i].temps_moy /(double) tab[i].nb_appel;
	}
}

void AfficheTab(Ligne tab[], int size) {
  int i;
  if (tab == NULL) {
    exit(1);
  }

  printf("temps    nb_appel   temps_moy  nom  \n");
  for (i = 0; i < size; i++) {
    printf("%lf %3d  \t %lf \t %s\n", tab[i].times, tab[i].nb_appel, tab[i].temps_moy, tab[i].name);
  }

}




int CompareAppel(const void * a, const void * b) {
   /*return ( *(double*)a - *(double*)b );*/
	  Ligne* p = (Ligne*)a;
     Ligne* p2 = (Ligne*)b;
 
     return (p2->nb_appel - p->nb_appel);
}

int CompareName(const void * a, const void * b) {
   /*return ( *(double*)a - *(double*)b );*/
	  Ligne* p = (Ligne*)a;
     Ligne* p2 = (Ligne*)b;
 
     return (strcmp(p->name,p2->name));
}

int CompareTime(const void * a, const void * b) {
   /*return ( *(double*)a - *(double*)b );*/
	  Ligne* p = (Ligne*)a;
     Ligne* p2 = (Ligne*)b;
 
     return (p2->times - p->times);
}

int CompareTemp_moy(const void * a, const void * b) {
   /*return ( *(double*)a - *(double*)b );*/
	  Ligne* p = (Ligne*)a;
     Ligne* p2 = (Ligne*)b;
 
     return (p2->temps_moy - p->temps_moy);
}















