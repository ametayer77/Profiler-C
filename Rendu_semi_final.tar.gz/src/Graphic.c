

#include "../include/Graphic.h"





int  Frered_aux(Arbre a) {
  if (a == NULL) {
    return 0;
  }
  if (strcmp(a->name, "END")) {
    return 1 + Frered_aux(a->frd);
  }
  return 0;
}



void Convert_char(char *chaine, char *res, int size) {
  int i;
  for (i = 0; i < size ; i++) {
    res[i] = chaine[i];
  }
  res[i+1] = '\0';
}


void DessinRect(Arbre a, int widht, int height, int x, int y, MLV_Font* font, double ref, int couleur, int *tmp) {
  int nb_fr = 0;

 /*MLV_clear_window(MLV_COLOR_BLACK);*/
  if (a == NULL) {
  return;
  }
  if (strcmp(a->name, "END")) {


if (*tmp == 0) {
    *tmp = Frered_aux(a);
  widht =  (widht )/(*tmp);
  /*height = (height)/(*tmp);*/

}

int t;
  
  MLV_get_size_of_text_with_font(a->name, &t, NULL, font);
  printf("taille %d w=%d\n",t, widht-10 );

   MLV_draw_filled_rectangle(x, y, widht, height, MLV_rgba(255 * (a->real_times / ref), 255 - (255 * a->real_times / ref), 0, 255));
  MLV_draw_rectangle(x, y, widht, height, MLV_COLOR_BLACK);
  
  printf("Couleur %lf %lf Temps : %lf\n", 255 * (a->real_times / ref), 255 - (255 * a->real_times / ref), a->real_times);


  if (t > widht -20) {
    char res[BUFSIZ];
    /*printf("pass %s\n",a->name );*/
    Convert_char(a->name, res, strlen(a->name)/2);
     MLV_draw_text_with_font(x, y, "%s", font, MLV_COLOR_WHITE, res);
     printf("----%s\n",res );

  }
  else {
    MLV_draw_text_with_font(x, y, "%s", font, MLV_COLOR_WHITE, a->name);
  }


   /*printf("%s (%lf,%lf) long %lf larg %lf \n",a->name, *x, *y, *widht, *height );*/

  MLV_actualise_window();
 /* MLV_wait_mouse(&t, &r);*/

/*
    if (*height < 40) {
    	MLV_draw_text_with_font(*x, *y-10, "...", font, MLV_COLOR_WHITE);
    }
  else {
  	MLV_draw_text_with_font(*x, *y, "%s", font, MLV_COLOR_WHITE, a->name);
  }



  
   MLV_actualise_window();
  
   *x += 10;
   *y += 50;

   */
   

  }
  
  DessinRect(a->fg, widht , height -30, x +20 , y +30, font, ref, couleur, &nb_fr);
  DessinRect(a->frd, widht, height, x + widht -20, y, font, ref, couleur, tmp);
 

}


void Graphic(Arbre b){
  int x, y;
  x = 0;
  y = 0;
  int tmp = 0;
  MLV_create_window( "Profileur", "Profileur", WIDHT , HEIGHT);


  MLV_Font* font;

  font = MLV_load_font( "../include/font/DejaVuSerif-Bold.ttf" , 25);
  if (font == NULL) {
    exit(1);
  }
  int widht = WIDHT  ;
  int height = HEIGHT ;

  DessinRect(b, widht, height, x, y, font, b->real_times, 0, &tmp);


  int z, r;
  MLV_wait_mouse(&z,&r);


  MLV_free_font(font);
  MLV_free_window();




}    