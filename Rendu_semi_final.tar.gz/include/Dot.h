#ifndef __Dot__
#define __Dot__ 



#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#include "Arbre.h"
#include "macro_profileur.h"

/** \fn void dessine(Arbre a)
*  \brief Utilise dot pour afficher un arbre
*  \param Arbre a   -> arbre à afficher
*  \return void
**/
void dessine(Arbre a);



#endif