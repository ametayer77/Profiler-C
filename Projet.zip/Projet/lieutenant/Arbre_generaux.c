/* AUTHOR : Metayer Ambre & Saouter Marion
*  Creation 15-11-2018
∗  Change  */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <MLV/MLV_all.h>



/*Taille maximal de la fenêtre*/
#define WIDHT MLV_get_desktop_width()
#define HEIGHT MLV_get_desktop_height()




/* Structure permettant de déclarer un type d'arbre */
typedef struct noeud {
  double times;
  char name[BUFSIZ];
  struct noeud *fg;
  struct noeud *frd;
}Noeud, *Arbre;



typedef struct {
  double times;
  char name[BUFSIZ];
  int nb_appel;
  double temps_moy;
  double temps_inst;
}Ligne;



/* BUT : Alloue un noeud d'un Arbre
*  Paramètres : int val -> étiquette du noeud
*  Renvoi : un pointeur sur un noeud
*/
Arbre AlloueNoeud(double times, char name[]) {

    Arbre tmp;
    tmp = (Arbre)malloc(sizeof(Noeud));

    if (tmp != NULL) {
        tmp->times = times;
        strcpy(tmp->name, name);
        tmp->fg = NULL;
        tmp->frd = NULL;
        
    }
    return tmp;
}





/* BUT : Construire un arbre à partir d'un fichier '*fichier'
*  Paramètres : Arbre *a      -> Arbre à construire
*               FILE *fichier -> fichier texte
*  Renvoi : le nombre de noeud qui à 2 fils
*/
Arbre construitArbre(Arbre *a, FILE *fichier) {


  double times;
  char name[50];


    while(fscanf(fichier, "%s %*s %*s %*s %lf %*s",name, &times ) != EOF ) {
    	
    	(*a) = AlloueNoeud(times, name);
        construitArbre(&((*a)->fg), fichier);
        construitArbre(&((*a)->frd), fichier);
    }

  return *a;

}


/* BUT : Affiche un Arbre 'a'
*  Paramètres : Arbre a -> Arbre à afficher
*  Renvoi : void
*/
void afficheArbre(Arbre a) {

  if (a == NULL) {
    return;
  }
  printf("%s %f \n",a->name, a->times);
  afficheArbre(a->fg);
  afficheArbre(a->frd);

}




/* BUT : Utilise dot 
*  Paramètres : FILE *out -> fichier de sortie
*  Renvoi : void
*/
void ecrireDebut(FILE * out){
  fprintf(out, "digraph arbre {\n");
  fprintf(out, "\tnode [shape=record,height=.1]\n");
  fprintf(out, "\tedge [tailclip=false, arrowtail=dot, dir=both];\n");
}



/* BUT : Utilise dot pour afficher l'arbre a
*  Paramètres : FILE *out -> fichier de sortie
*       Arbre a   -> arbre à afficher
*  Renvoi : void
*/
void ecrireArbre(FILE * out, Arbre a){


    if(a == NULL) {
        return;
    }


    if(a->fg == NULL ){
        fprintf(out, "\n");
        fprintf(out, "n%p [label= \"<gauche>  | <times> %f | <droit>\"]", a, a->times);
        fprintf(out, "n%p : droit : c -> n%p : times;", a, a->frd);
        return;
    }

    if (a->frd != NULL) {
        
    }

    /*
    if(a->fg == NULL && a->frd == NULL){
        fprintf(out, "\n");
        fprintf(out, "n%p [label= \"<gauche>  | <times> %f | <droit>\"]", a, a->times);
        fprintf(out, "n%p : gauche : c -> n%p : times;", a, a->fg);
        return;
    }

    if(a->fg != NULL && a->frd == NULL){
        fprintf(out, "\n");
        fprintf(out, "n%p [label= \"<gauche>  | <times> %f | <droit>\"]", a, a->times);
        fprintf(out, "n%p : gauche : c -> n%p : times;", a, a->fg);
        

    }

    if(a->frd != NULL && a->fg == NULL){
        fprintf(out, "\n");
        fprintf(out, "n%p [label= \"<gauche>  | <times> %f | <droit>\"]", a, a->times);
        fprintf(out, "n%p : droit : c -> n%p : times;", a, a->frd);
        

    }

    if(a->fg != NULL && a->frd != NULL){
        fprintf(out, "\n");
        fprintf(out, "n%p [label= \"<gauche>  | <times> %f | <droit>\"]", a, a->times);
        fprintf(out, "n%p : gauche : c -> n%p : times;", a, a->fg);
        fprintf(out, "n%p : droit : c -> n%p : times;", a, a->frd);
        
    }
    */

    ecrireArbre(out, a->fg);
    ecrireArbre(out, a->frd);



}


/* BUT : Utilise dot 
*  Paramètres : FILE *out -> fichier de sortie
*  Renvoi : void
*/
void ecrireFin(FILE * out){
  fprintf(out, "\n}\n");
}


/* BUT : Utilise dot poure afficher un arbre
*  Paramètres : Arbre a   -> arbre à afficher
*  Renvoi : void
*/
void dessine(Arbre a){

  FILE * out;
  out = fopen("arbre.dot", "w");
  ecrireDebut(out);
  ecrireArbre(out, a);
  ecrireFin(out);
  fclose(out);
  system("dot -Tpdf arbre.dot -o arbre.pdf");
  system("evince arbre.pdf &");
}





void construitTab(Arbre a, Ligne *tab, int size, int i, double tmp) {
	if (a == NULL) {
    return;
  }

  
  construitTab(a->fg, tab, size, i+1, tmp);
  strcpy(tab[i].name, a->name);
  tab[i].nb_appel = 1;
  
  construitTab(a->frd, tab, size, i, tmp);
  tmp = a->times;
  printf("%lf z=et %s \n",tmp, tab[i].name );
}



void AfficheTab(Ligne *tab, int size) {
  int i;
  if (tab == NULL) {
    exit(1);
  }

  printf("nom  temps    nb_appel   temps_moy temps_inst\n");
  for (i = 0; i < size; i++) {
    printf("%s %lf %d  \t %lf %lf\n",tab[i].name, tab[i].times, tab[i].nb_appel, tab[i].temps_moy, tab[i].temps_inst );
  }

}



int main( int argc, char *argv[] ){


   int size = 4;
    Ligne tab_test[size];

    int x, y;
    int deplace = 10;
    int i;
    int taille = 30;
   


    strcpy(tab_test[0].name,"main");
    tab_test[0].nb_appel = 1;
    tab_test[0].times = 1546175678.613577 - 1546175678.610796;
    tab_test[0].temps_moy = tab_test[0].times / tab_test[0].nb_appel;
    tab_test[0].temps_inst = tab_test[0].times;


    strcpy(tab_test[1].name,"fact");
    tab_test[1].nb_appel = 2;
    tab_test[1].times = 1546175678.613501 - 1546175678.611014;
    tab_test[1].temps_moy = (tab_test[1].times +  1546175678.613432 - 1546175678.613281) / tab_test[1].nb_appel;
    tab_test[1].temps_inst = tab_test[1].times;



     strcpy(tab_test[2].name,"main2");
    tab_test[2].nb_appel = 1;
    tab_test[2].times = 1546175678.613577 - 1546175678.610796;
    tab_test[2].temps_moy = tab_test[2].times / tab_test[2].nb_appel;
    tab_test[2].temps_inst = tab_test[2].times;


    strcpy(tab_test[3].name,"fact2");
    tab_test[3].nb_appel = 2;
    tab_test[3].times = 1546175678.613501 - 1546175678.611014;
    tab_test[3].temps_moy = (tab_test[3].times +  1546175678.613432 - 1546175678.613281) / tab_test[3].nb_appel;
    tab_test[3].temps_inst = tab_test[3].times;


    AfficheTab(tab_test, size);


    MLV_create_window( "Profileur", "Profileur", WIDHT, HEIGHT);


    MLV_Font* font;

    font = MLV_load_font( "./font/DejaVuSerif-Bold.ttf" , taille);
    if (font == NULL) {
      exit(1);
    }

    /*Pour eviter que le nom de  la fct touche le cadre*/
    taille +=5;
    int pas = 50;


    for (i = 0; i < size; i++) {
      /*
      if (i %2 != 0) {
        
         MLV_draw_filled_rectangle(i * deplace , taille*i, WIDHT - i *100, HEIGHT - i *100, MLV_COLOR_GREEN );
         MLV_draw_text_with_font(i * deplace +5, taille*i, "%s", font, MLV_COLOR_WHITE, tab_test[i].name);
      }
      else{

       MLV_draw_filled_rectangle(i * deplace , taille*i, WIDHT - i *10, HEIGHT - i *10, MLV_COLOR_RED );
       MLV_draw_text_with_font(i * deplace +5 , taille*i, "%s", font, MLV_COLOR_WHITE, tab_test[i].name);
      
    }
    */
   


    MLV_draw_filled_rectangle(i * deplace , taille*i, WIDHT - i *100, HEIGHT - i *100, MLV_rgba(255 -i*pas, 0 +i*pas, 0, 255));
    MLV_draw_text_with_font(i * deplace +5 , taille*i, "%s", font, MLV_COLOR_WHITE, tab_test[i].name);

    MLV_actualise_window();
    // MLV_wait_mouse(&x,&y);
  
}


    


    MLV_actualise_window();

    MLV_wait_mouse(&x,&y);

   
    MLV_free_font(font);
    MLV_free_window();



    return 0;

}











