/* AUTHOR : Metayer Ambre & Saouter Marion
*  Creation 15-11-2018
∗  Change  */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>




/* Structure permettant de déclarer un type d'arbre */
typedef struct noeud {
  double valeur;
  struct noeud *fg;
  struct noeud *frd;
}Noeud, *Arbre;



/* BUT : Alloue un noeud d'un Arbre
*  Paramètres : int val -> étiquette du noeud
*  Renvoi : un pointeur sur un noeud
*/
Arbre AlloueNoeud(double val) {

    Arbre tmp;
    tmp = (Arbre)malloc(sizeof(Noeud));

    if (tmp != NULL) {
        tmp->valeur = val;
        tmp->fg = NULL;
        tmp->frd = NULL;
        
    }
    return tmp;
}





/* BUT : Construire un arbre à partir d'un fichier '*fichier'
*  Paramètres : Arbre *a      -> Arbre à construire
*               FILE *fichier -> fichier texte
*  Renvoi : le nombre de noeud qui à 2 fils
*/
Arbre construitArbre(Arbre *a, FILE *fichier) {

 
  int caractereActuel;
  double test;

  do{   
        caractereActuel = fgetc(fichier); 
        
        if (caractereActuel == ':') {
            fgetc(fichier);
            fscanf(fichier, "%lf", &test);
            (*a) = AlloueNoeud(test);
            construitArbre(&((*a)->fg), fichier);
            construitArbre(&((*a)->frd), fichier);
        }

    } while (caractereActuel != EOF ); 

  return *a;

}


/* BUT : Affiche un Arbre 'a'
*  Paramètres : Arbre a -> Arbre à afficher
*  Renvoi : void
*/
void afficheArbre(Arbre a) {

  if (a == NULL) {
    return;
  }
  printf("%f \n",a->valeur);
  afficheArbre(a->fg);
  afficheArbre(a->frd);

}




/* BUT : Utilise dot 
*  Paramètres : FILE *out -> fichier de sortie
*  Renvoi : void
*/
void ecrireDebut(FILE * out){
  fprintf(out, "digraph arbre {\n");
  fprintf(out, "\tnode [shape=record,height=.1]\n");
  fprintf(out, "\tedge [tailclip=false, arrowtail=dot, dir=both];\n");
}



/* BUT : Utilise dot pour afficher l'arbre a
*  Paramètres : FILE *out -> fichier de sortie
*       Arbre a   -> arbre à afficher
*  Renvoi : void
*/
void ecrireArbre(FILE * out, Arbre a){


    if(a == NULL) {
        return;
    }


    if(a->fg == NULL ){
        fprintf(out, "\n");
        fprintf(out, "n%p [label= \"<gauche>  | <valeur> %f | <droit>\"]", a, a->valeur);
        fprintf(out, "n%p : droit : c -> n%p : valeur;", a, a->frd);
        return;
    }

    if (a->frd != NULL) {
        
    }

    /*
    if(a->fg == NULL && a->frd == NULL){
        fprintf(out, "\n");
        fprintf(out, "n%p [label= \"<gauche>  | <valeur> %f | <droit>\"]", a, a->valeur);
        fprintf(out, "n%p : gauche : c -> n%p : valeur;", a, a->fg);
        return;
    }

    if(a->fg != NULL && a->frd == NULL){
        fprintf(out, "\n");
        fprintf(out, "n%p [label= \"<gauche>  | <valeur> %f | <droit>\"]", a, a->valeur);
        fprintf(out, "n%p : gauche : c -> n%p : valeur;", a, a->fg);
        

    }

    if(a->frd != NULL && a->fg == NULL){
        fprintf(out, "\n");
        fprintf(out, "n%p [label= \"<gauche>  | <valeur> %f | <droit>\"]", a, a->valeur);
        fprintf(out, "n%p : droit : c -> n%p : valeur;", a, a->frd);
        

    }

    if(a->fg != NULL && a->frd != NULL){
        fprintf(out, "\n");
        fprintf(out, "n%p [label= \"<gauche>  | <valeur> %f | <droit>\"]", a, a->valeur);
        fprintf(out, "n%p : gauche : c -> n%p : valeur;", a, a->fg);
        fprintf(out, "n%p : droit : c -> n%p : valeur;", a, a->frd);
        
    }
    */

    ecrireArbre(out, a->fg);
    ecrireArbre(out, a->frd);



}


/* BUT : Utilise dot 
*  Paramètres : FILE *out -> fichier de sortie
*  Renvoi : void
*/
void ecrireFin(FILE * out){
  fprintf(out, "\n}\n");
}


/* BUT : Utilise dot poure afficher un arbre
*  Paramètres : Arbre a   -> arbre à afficher
*  Renvoi : void
*/
void dessine(Arbre a){

  FILE * out;
  out = fopen("arbre.dot", "w");
  ecrireDebut(out);
  ecrireArbre(out, a);
  ecrireFin(out);
  fclose(out);
  system("dot -Tpdf arbre.dot -o arbre.pdf");
  system("evince arbre.pdf &");
}



int main( int argc, char *argv[] ){


    printf("hhd\n");
    Arbre a = NULL;
    FILE *fichier1 = fopen("profile.log", "r");
    construitArbre(&a, fichier1);
    afficheArbre(a);
    dessine(a);



    return 0;

}











