/* AUTHOR : Metayer Ambre & Saouter Marion
*  Creation 15-11-2018
∗  Change  */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>





/* Structure permettant de déclarer un type d'arbre */
typedef struct noeud {
  double times;
  char name[BUFSIZ];
  double real_times;
  double temps_inst;
  struct noeud *fg;
  struct noeud *frd;
}Noeud, *Arbre;



typedef struct {
  double times;
  char name[BUFSIZ];
  int nb_appel;
  double temps_moy;
  double temps_inst;
}Ligne;



/* BUT : Alloue un noeud d'un Arbre
*  Paramètres : int val -> étiquette du noeud
*  Renvoi : un pointeur sur un noeud
*/
Arbre AlloueNoeud(double times, char name[]) {

    Arbre tmp;
    tmp = (Arbre)malloc(sizeof(Noeud));

    if (tmp != NULL) {
        tmp->times = times;
        strcpy(tmp->name, name);
        tmp->fg = NULL;
        tmp->frd = NULL;
        tmp->real_times = 0;
        tmp->temps_inst = 0;
        
    }
    return tmp;
}





/* BUT : Construire un arbre à partir d'un fichier '*fichier'
*  Paramètres : Arbre *a      -> Arbre à construire
*               FILE *fichier -> fichier texte
*  Renvoi : le nombre de noeud qui à 2 fils
*/
void construitArbre(Arbre *a, FILE *fichier) {


  double times;
  char name[50];


    if(fscanf(fichier, "%s %*s %*s %*s %lf %*s",name, &times ) != EOF ) {



      (*a) = AlloueNoeud(times, name);
      if (strcmp(name, "END")) {

        construitArbre(&((*a)->fg), fichier);
         construitArbre(&((*a)->frd), fichier);
         return;
        
      }

      
    }
}



/*
void  ModifieArbre(Arbre *a, double *test, double *inst) {


  if (*a == NULL) {
    return;
  }
 


 
ModifieArbre(&(*a)->fg, test, inst);

ModifieArbre(&(*a)->frd, test, inst);

   if (!strcmp((*a)->name, "END")) {
    
   *test = (*a)->times;
   /inst = (*a)->temps_inst;

   
}

else {
 
   (*a)->temps_inst = *test - (*a)->times;
   (*a)->real_times =  (*a)->temps_inst - *inst;
//printf("time %lf val %lf *inst %lf ", (*a)->times, *test, *inst);
  printf("ap %s temps_fct: %f temps_cumul: %f \n", (*a)->name, (*a)->real_times, (*a)->temps_inst);
  // *inst = (*a)->temps_inst;

   //printf("ap inst %lf\n",*inst );
  
   

}



void  ModifieArbre(Arbre *a, double *test, double *inst) {


  if (*a == NULL) {

    return;

  }
 
  

 
   ModifieArbre(&(*a)->fg, test, inst);



   if (!strcmp((*a)->name, "END")) {
    
   *test = (*a)->times;
}

else {
  
  (*a)->real_times = *test - (*a)->times;
  

   if(*inst >= (*a)->real_times) {
     (*a)->temps_inst =  (*a)->real_times;
      *inst = (*a)->temps_inst;
   }
   else {
   

    (*a)->temps_inst =  (*a)->real_times - (*inst );
     *inst += (*a)->temps_inst;

    printf("%lf %lf %lf \n", (*a)->real_times, *inst, (*a)->temps_inst );
   
  }
  
  

 }
ModifieArbre(&(*a)->frd, test, inst);

}

  

}
*/




/*

void  ModifieArbre(Arbre *a, double *test, double *inst, double *frd) {


  if (*a == NULL) {

    return;

  }
 
  

 
   ModifieArbre(&(*a)->fg, test, inst, frd);



   if (!strcmp((*a)->name, "END")) {
    
   *test = (*a)->times;
   *frd = 0;
}

else {
  
  (*a)->real_times = *test - (*a)->times;
  

   if(*inst >= (*a)->real_times) {
     (*a)->temps_inst =  (*a)->real_times;
      *inst = (*a)->temps_inst;
      *frd = 0;
   }
   else {
   

    (*a)->temps_inst =  (*a)->real_times - *inst ;
     *frd += *inst;
    printf("%lf %lf %lf+ %lf  \n", (*a)->real_times, *inst, (*a)->temps_inst, *frd );

     *inst  = (*a)->temps_inst + *frd;

    
   
  }
  
  

 }

ModifieArbre(&(*a)->frd, test, inst, frd);

}




void  ModifieArbre(Arbre *a, double *test, double *inst) {


  if (*a == NULL) {

    return;

  }
 
  

 
   ModifieArbre(&(*a)->fg, test, inst);



   if (!strcmp((*a)->name, "END")) {
    
   *test = (*a)->times;
}

else {
  
  (*a)->real_times = *test - (*a)->times;
  

   if(*inst >= (*a)->real_times) {
     (*a)->temps_inst =  (*a)->real_times;
      *inst = (*a)->temps_inst;
   }
   else {
   

    (*a)->temps_inst =  (*a)->real_times - *inst ;
    printf("%lf %lf %lf \n", (*a)->real_times, *inst, (*a)->temps_inst );
     *inst  = (*a)->temps_inst;

    
   
  }
  
  

 }
ModifieArbre(&(*a)->frd, test, inst);

}*/
  



void  ModifieArbre(Arbre *a, double *test, double *inst, double *frd) {

  if (*a == NULL) {

    return;

  }

  ModifieArbre(&(*a)->fg, test, inst, frd);




  if (!strcmp((*a)->name, "END")) {

    *test = (*a)->times;
  }

  else {

    (*a)->real_times = *test - (*a)->times;

    if(*inst >= (*a)->real_times) {
    (*a)->temps_inst =  (*a)->real_times;
    *inst = (*a)->temps_inst;

    }
    else {
       (*a)->temps_inst =  (*a)->real_times - *inst;
    if((*a)->frd != NULL ) {
      if(strcmp((*a)->frd->name, "END")) {
        *frd += (*a)->temps_inst;
      }
      else {

      }
    //(*a)->temps_inst =  (*a)->real_times - *inst -*frd;

    


    *inst  = (*a)->temps_inst;

  }

  }
   //*frd += (*a)->temps_inst;
    if(*frd > (*a)->temps_inst && strcmp((*a)->name, "END"))
    printf("%s %lf +%lf = %lf\n", (*a)->name, *frd, (*a)->temps_inst, *frd +(*a)->temps_inst );


    }
  ModifieArbre(&(*a)->frd, test, inst, frd);

}






/* BUT : Affiche un Arbre 'a'
*  Paramètres : Arbre a -> Arbre à afficher
*  Renvoi : void
*/
void afficheArbre(Arbre a) {

  if (a == NULL) {
    return;
  }
  printf("%s %f %lf\n",a->name, a->times, a->real_times);
  afficheArbre(a->fg);
  afficheArbre(a->frd);

}




/* BUT : Utilise dot 
*  Paramètres : FILE *out -> fichier de sortie
*  Renvoi : void
*/
void ecrireDebut(FILE * out){
  fprintf(out, "digraph arbre {\n");
  fprintf(out, "\tnode [shape=record,height=.1]\n");
  fprintf(out, "\tedge [tailclip=false, arrowtail=dot, dir=both];\n");
}





void ecrireArbre(FILE * out, Arbre a){


    if(a == NULL) {
        return;
    }

     
    fprintf(out, "\n");
    fprintf(out, "n%p [label= \"<gauche>  | <valeur> %s temps_fct: %f temps_cumul: %f | <droit>\"]", a, a->name, a->real_times, a->temps_inst);
          

    if(a->fg != NULL ){
      
      fprintf(out, "n%p : gauche : c -> n%p : valeur;", a, a->fg);
        
    }

    if(a->frd != NULL ){
       
        fprintf(out, "n%p : droit : c -> n%p : valeur;", a, a->frd);
        
  }

    ecrireArbre(out, a->fg);
    ecrireArbre(out, a->frd);

}

/*


void ecrireArbre(FILE * out, Arbre a){


  if(a == NULL) {
      return;
  }

  if (strcmp(a->name, "END")) {
    fprintf(out, "\n");
    fprintf(out, "n%p [label= \"<gauche>  | <valeur> %s %f %f | <droit>\"]", a, a->name,  a->temps_inst, a->real_times);
      
    

    if(a->fg != NULL && strcmp(a->fg->name, "END")){
      fprintf(out, "n%p : gauche : c -> n%p : valeur;", a, a->fg);

    }

    if(a->frd != NULL && strcmp(a->frd->name, "END")){
      fprintf(out, "n%p : droit : c -> n%p : valeur;", a, a->frd);
    }

  }

  ecrireArbre(out, a->fg);
  ecrireArbre(out, a->frd);

}
*/



/* BUT : Utilise dot 
*  Paramètres : FILE *out -> fichier de sortie
*  Renvoi : void
*/
void ecrireFin(FILE * out){
  fprintf(out, "\n}\n");
}


/* BUT : Utilise dot poure afficher un arbre
*  Paramètres : Arbre a   -> arbre à afficher
*  Renvoi : void
*/
void dessine(Arbre a){

  FILE * out;
  out = fopen("arbre.dot", "w");
  ecrireDebut(out);
  ecrireArbre(out, a);
  ecrireFin(out);
  fclose(out);
  system("dot -Tpdf arbre.dot -o arbre.pdf");
  system("evince arbre.pdf &");
}






int main( int argc, char *argv[] ){

  Arbre a = NULL;
  Arbre b = NULL;
  FILE *fichier;
  double test = 0;
  double inst = 0;
  double frd = 0;
  fichier = fopen("profile.log", "r");

  construitArbre(&a, fichier);
 

  printf("\n");
  rewind(fichier);
  construitArbre(&b, fichier);
  ModifieArbre(&b, &test, &inst, &frd);
  //ModifieArbre(&b, &test, &inst);
  fclose(fichier);

 dessine(b);


  return 0;

}











